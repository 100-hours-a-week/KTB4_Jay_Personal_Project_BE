# PostEditPage 정적 페이지

## 기존 기준 파일

```
vanilla-js-frontend/html/posts.html
```

기존 section:

```
post-edit-section
```

## 화면 목적

PostEditPage는 기존 게시글을 수정하는 화면입니다.

정적 페이지 단계에서는 기존 게시글 데이터를 실제로 불러오지 않고, 수정 화면의 구조만 만듭니다.

## 화면에 보여야 하는 요소

```
- Amend Commit 제목
- commit.title label
- 제목 input
- commit.body label
- 내용 textarea
- Deploy Patch 버튼
- Cancel 버튼
```

기존 HTML 기준으로는 아래 id/class를 참고합니다.

```
post-edit-section
edit-title-input
edit-content-input
update-post-button
cancel-edit-button
```

## 컴포넌트 분리

React에서는 아래 페이지로 만듭니다.

```
PostEditPage.jsx
```

## 아직 구현하지 않을 기능

```
- 기존 게시글 상세 조회
- title state 관리
- content state 관리
- 게시글 수정 API 요청
- 수정 성공 후 상세 페이지 이동
- Cancel 버튼 클릭 시 상세 페이지 이동
```

## 완료 조건

```
- Amend Commit 제목이 보입니다.
- 제목 input이 보입니다.
- 내용 textarea가 보입니다.
- Deploy Patch 버튼이 보입니다.
- Cancel 버튼이 보입니다.
```

---

![image.png](PostEditPage%20%EC%A0%95%EC%A0%81%20%ED%8E%98%EC%9D%B4%EC%A7%80/image.png)