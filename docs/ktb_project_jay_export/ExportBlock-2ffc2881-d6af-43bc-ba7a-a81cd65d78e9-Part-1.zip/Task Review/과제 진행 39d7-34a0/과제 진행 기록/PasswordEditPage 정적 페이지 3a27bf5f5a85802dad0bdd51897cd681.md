# PasswordEditPage 정적 페이지

## 기존 기준 파일

```
vanilla-js-frontend/html/profile.html
```

기존 section:

```
password-edit-section
```

## 화면 목적

PasswordEditPage는 사용자가 비밀번호를 변경하는 화면입니다.

정적 페이지 단계에서는 입력창과 버튼만 만들고, 실제 비밀번호 검증과 API 요청은 하지 않습니다.

## 화면에 보여야 하는 요소

```
- Back to Feed 버튼
- Rotate Secret 제목
- current secret label
- current secret input
- current secret helper message 영역
- new secret label
- new secret input
- new secret helper message 영역
- confirm new secret label
- confirm new secret input
- confirm new secret helper message 영역
- Rotate 버튼
```

기존 HTML 기준으로는 아래 id/class를 참고합니다.

```
password-edit-section
password-back-to-list-button
current-password-input
current-password-error
new-password-input
new-password-error
new-password-check-input
new-password-check-error
update-password-button
```

## 컴포넌트 분리

React에서는 아래 페이지로 만듭니다.

```
PasswordEditPage.jsx
```

## 아직 구현하지 않을 기능

```
- currentPassword state 관리
- newPassword state 관리
- newPasswordCheck state 관리
- 비밀번호 검증
- 비밀번호 변경 API 요청
- 성공 메시지 표시
- Back to Feed 버튼 이동
```

## 완료 조건

```
- Rotate Secret 제목이 보입니다.
- current secret 입력창이 보입니다.
- new secret 입력창이 보입니다.
- confirm new secret 입력창이 보입니다.
- 각 입력창 아래 helper message 영역이 있습니다.
- Rotate 버튼이 보입니다.
```

![image.png](PasswordEditPage%20%EC%A0%95%EC%A0%81%20%ED%8E%98%EC%9D%B4%EC%A7%80/image.png)