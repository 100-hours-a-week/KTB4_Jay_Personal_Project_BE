# ConfirmModal 정적 페이지

## 기존 기준 파일

```
vanilla-js-frontend/html/profile.html
```

기존 요소:

```
delete-user-modal
```

## 화면 목적

ConfirmModal은 회원 탈퇴 전에 사용자에게 한 번 더 확인을 받기 위한 모달입니다.

정적 페이지 단계에서는 모달 UI만 만듭니다.

## 화면에 보여야 하는 요소

```
- Delete Account? 제목
- All commits and threads will be removed. 문구
- Cancel 버튼
- Confirm 버튼
```

기존 HTML 기준으로는 아래 id/class를 참고합니다.

```
delete-user-modal
confirm-modal
cancel-delete-user-button
confirm-delete-user-button
```

## 컴포넌트 분리

React에서는 아래 컴포넌트로 만듭니다.

```
ConfirmModal.jsx
```

## 아직 구현하지 않을 기능

```
- 모달 열기/닫기 상태 관리
- Cancel 클릭 시 모달 닫기
- Confirm 클릭 시 회원 탈퇴 API 요청
```

## 완료 조건

```
- 모달 배경이 보입니다.
- Delete Account? 제목이 보입니다.
- 안내 문구가 보입니다.
- Cancel 버튼이 보입니다.
- Confirm 버튼이 보입니다.
```

![image.png](ConfirmModal%20%EC%A0%95%EC%A0%81%20%ED%8E%98%EC%9D%B4%EC%A7%80/image.png)