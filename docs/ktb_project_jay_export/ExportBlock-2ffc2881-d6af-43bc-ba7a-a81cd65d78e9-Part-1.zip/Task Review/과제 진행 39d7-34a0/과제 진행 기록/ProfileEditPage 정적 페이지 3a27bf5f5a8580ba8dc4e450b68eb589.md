# ProfileEditPage 정적 페이지

## 기존 기준 파일

```
vanilla-js-frontend/html/profile.html
```

기존 section:

```
profile-edit-section
```

## 화면 목적

ProfileEditPage는 사용자가 닉네임과 프로필 이미지를 수정하는 화면입니다.

정적 페이지 단계에서는 실제 저장 기능 없이 입력창과 버튼만 만듭니다.

## 화면에 보여야 하는 요소

```
- Back to Feed 버튼
- Profile Config 제목
- avatar label
- 프로필 이미지 변경 영역
- change 문구
- email label
- email 읽기 전용 표시
- handle label
- nickname input
- nickname helper message 영역
- Save Config 버튼
- Delete Account 버튼
```

기존 HTML 기준으로는 아래 id/class를 참고합니다.

```
profile-edit-section
profile-back-to-list-button
profile-edit-preview
profile-image-input
profile-edit-email
profile-nickname-input
profile-nickname-error
update-profile-button
delete-user-button
```

## 컴포넌트 분리

React에서는 아래 페이지로 만듭니다.

```
ProfileEditPage.jsx
```

회원 탈퇴 확인창은 따로 분리합니다.

```
ConfirmModal.jsx
```

## 아직 구현하지 않을 기능

```
- 기존 사용자 정보 조회
- nickname state 관리
- 프로필 이미지 선택
- 프로필 이미지 미리보기
- 프로필 수정 API 요청
- Delete Account 버튼 클릭 시 모달 열기
- 회원 탈퇴 API 요청
```

## 완료 조건

```
- Profile Config 제목이 보입니다.
- 프로필 이미지 변경 영역이 보입니다.
- email 표시 영역이 보입니다.
- handle 입력창이 보입니다.
- Save Config 버튼이 보입니다.
- Delete Account 버튼이 보입니다.
```

![image.png](ProfileEditPage%20%EC%A0%95%EC%A0%81%20%ED%8E%98%EC%9D%B4%EC%A7%80/image.png)