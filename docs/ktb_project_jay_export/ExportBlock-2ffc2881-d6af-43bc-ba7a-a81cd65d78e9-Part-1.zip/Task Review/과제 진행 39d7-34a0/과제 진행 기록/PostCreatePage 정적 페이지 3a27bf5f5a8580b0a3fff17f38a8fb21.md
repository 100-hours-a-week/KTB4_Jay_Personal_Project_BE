# PostCreatePage 정적 페이지

## 기존 기준 파일

```
vanilla-js-frontend/html/posts.html
```

기존 section:

```
post-create-section
```

## 화면 목적

PostCreatePage는 새 게시글을 작성하는 화면입니다.

기존에서는 제목과 내용을 입력한 뒤 게시글 작성 API를 호출하고, 임시저장도 할 수 있었습니다.

정적 페이지 단계에서는 입력창과 버튼만 먼저 만듭니다.

## 화면에 보여야 하는 요소

```
- New Commit 제목
- commit.title label
- 제목 input
- commit.body label
- 내용 textarea
- Deploy 버튼
- Stash 버튼
- Load Stash 버튼
- Cancel 버튼
```

기존 HTML 기준으로는 아래 id/class를 참고합니다.

```
post-create-section
create-title-input
create-content-input
create-post-button
save-draft-button
load-draft-button
cancel-create-button
```

## 컴포넌트 분리

React에서는 아래 페이지로 만듭니다.

```
PostCreatePage.jsx
```

## 아직 구현하지 않을 기능

정적 페이지 단계에서는 아래 기능을 아직 구현하지 않습니다.

```
- title state 관리
- content state 관리
- 제목/내용 빈 값 검증
- 게시글 작성 API 요청
- 임시저장 API 요청
- 임시저장 불러오기 API 요청
- 작성 성공 후 목록 이동
- Cancel 버튼 이동
```

## 완료 조건

```
- New Commit 제목이 보입니다.
- 제목 input이 보입니다.
- 내용 textarea가 보입니다.
- Deploy 버튼이 보입니다.
- Stash 버튼이 보입니다.
- Load Stash 버튼이 보입니다.
- Cancel 버튼이 보입니다.
```

![image.png](PostCreatePage%20%EC%A0%95%EC%A0%81%20%ED%8E%98%EC%9D%B4%EC%A7%80/image.png)

원래는 title, body 폭이 조금더 넓었는데 vanilla-js와 비교해서 작성을 해도 한번에 나오지는 않았습니다,,

사소한 폭이나 색상 같은 것들은 개발자가 직접하는게 조금더 낫다는 생각이 들었습니다,,

![image.png](PostCreatePage%20%EC%A0%95%EC%A0%81%20%ED%8E%98%EC%9D%B4%EC%A7%80/image%201.png)

여전히 버튼들의 원래 색상은 검정이였지만 이 색깔도 나쁘지 않은 것 같아서 유지하도록 하였습니다.