# WelcomePage 동적 기능

WelcomePage에는state가 필요 없습니다.

![image.png](WelcomePage%20%EB%8F%99%EC%A0%81%20%EA%B8%B0%EB%8A%A5/image.png)

입력값도 없고 API 요청도 없기 때문입니다.

이는 Join, Login 클릭시 navigate를 통해 이동하는 것만 넣었습니다.