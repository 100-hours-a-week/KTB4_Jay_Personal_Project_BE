# SignupPage 정적 페이지

## 기존 기준 파일

```
vanilla-js-frontend/html/auth.html
```

기존 section:

```
signup-section
```

## 화면 목적

SignupPage는 새 사용자가 회원가입하는 화면입니다.

이 화면에는 입력 필드가 많고 프로필 이미지 업로드 영역도 있습니다.

하지만 정적 페이지 단계에서는 실제 회원가입이나 이미지 미리보기 기능은 넣지 않고, 화면 구조만 먼저 만들었습니다.

## 화면에 보여야 하는 요소

![image.png](SignupPage%20%EC%A0%95%EC%A0%81%20%ED%8E%98%EC%9D%B4%EC%A7%80/image.png)

```
- 뒤로가기 버튼
- Join 제목
- avatar label
- 프로필 이미지 업로드 영역
- + 표시
- 프로필 이미지 helper message 영역
- email label
- email input
- email helper message 영역
- secret label
- password input
- password helper message 영역
- confirm secret label
- password check input
- password check helper message 영역
- handle label
- nickname input
- nickname helper message 영역
- Create Account 버튼
- already have access? Login 버튼
```

기존 HTML 기준으로는 아래 id/class를 참고합니다.

```
signup-section
signup-back-button
signup-profile-image-input
signup-profile-preview
signup-profile-plus
signup-profile-image-error
signup-email-input
signup-email-error
signup-password-input
signup-password-error
signup-password-check-input
signup-password-check-error
signup-nickname-input
signup-nickname-error
signup-button
cancel-signup-button
```

## 컴포넌트 분리

```
SignupPage.jsx
```

## 아직 구현하지 않을 기능

정적 페이지 단계에서는 아래 기능을 아직 구현하지 않습니다.

```
- email 입력값 state 관리
- password 입력값 state 관리
- passwordCheck 입력값 state 관리
- nickname 입력값 state 관리
- 프로필 이미지 선택
- 프로필 이미지 미리보기
- 입력값 검증
- 회원가입 버튼 disabled 처리
- 회원가입 API 요청
- 중복 email/nickname 에러 처리
- 회원가입 성공 후 로그인 페이지 이동
```

## 완료 조건

```
- Join 제목이 보입니다.
- avatar 업로드 영역이 보입니다.
- email 입력창이 보입니다.
- secret 입력창이 보입니다.
- confirm secret 입력창이 보입니다.
- handle 입력창이 보입니다.
- 각 필드 아래 helper message 영역이 있습니다.
- Create Account 버튼이 보입니다.
- Login 이동 버튼이 보입니다.
```

![image.png](SignupPage%20%EC%A0%95%EC%A0%81%20%ED%8E%98%EC%9D%B4%EC%A7%80/image%201.png)