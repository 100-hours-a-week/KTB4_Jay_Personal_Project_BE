# ProfilePage 정적 페이지

## 기존 기준 파일

```
vanilla-js-frontend/html/profile.html
```

기존 section:

```
profile-view-section
```

## 화면 목적

ProfilePage는 로그인한 사용자의 정보를 보여주는 화면입니다.

정적 페이지 단계에서는 실제 사용자 정보를 API로 조회하지 않고, 임시 사용자 정보를 넣어서 화면만 확인합니다.

## 화면에 보여야 하는 요소

```
- Profile 제목
- Config 버튼
- 프로필 이미지
- user.id
- email
- handle
```

기존 HTML 기준으로는 아래 id/class를 참고합니다.

```
profile-view-section
profile-view-edit-button
profile-view-image
profile-view-user-id
profile-view-email
profile-view-nickname
```

## 컴포넌트 분리

React에서는 아래 페이지로 만듭니다.

```
ProfilePage.jsx
```

## 정적 페이지에서 사용할 임시 데이터

```
userId
email
nickname
profileImage
```

## 아직 구현하지 않을 기능

```
- 내 정보 API 조회
- Config 버튼 클릭 시 프로필 수정 페이지 이동
- 로그인하지 않은 사용자 접근 제한
- 실제 프로필 이미지 처리
```

## 완료 조건

```
- Profile 제목이 보입니다.
- Config 버튼이 보입니다.
- 프로필 이미지가 보입니다.
- user.id가 보입니다.
- email이 보입니다.
- handle이 보입니다.
```

![image.png](ProfilePage%20%EC%A0%95%EC%A0%81%20%ED%8E%98%EC%9D%B4%EC%A7%80/image.png)