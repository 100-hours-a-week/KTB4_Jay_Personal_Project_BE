# PostListPage 정적 페이지

## 기존 기준 파일

```
vanilla-js-frontend/html/posts.html
```

기존 section:

```
post-list-section
```

## 화면 목적

PostListPage는 게시글 목록을 보여주는 화면입니다.

기존 vanilla JS에서는 서버에서 게시글 목록을 가져와서 `createElement`로 게시글 카드를 만들었습니다.

React 정적 페이지 단계에서는 서버 API를 연결하지 않고, 임시 게시글 데이터를 만들어서 카드가 어떻게 보이는지만 확인합니다.

## 화면에 보여야 하는 요소

```
- 게시판 소개 문구
- Login 버튼
- Commit 버튼
- Latest 버튼
- Hot 버튼
- 게시글 카드 목록
- 이전 버튼
- 현재 페이지 / 전체 페이지 표시
- 다음 버튼
```

기존 HTML 기준으로는 아래 id/class를 참고합니다.

```
post-list-section
post-list-intro
show-list-login-button
show-create-button
sort-latest-button
sort-popular-button
post-list
post-card
pagination
prev-page-button
page-info
next-page-button
```

## 컴포넌트 분리

React에서는 아래처럼 나눕니다.

```
PostListPage.jsx
PostCard.jsx
Pagination.jsx
```

`PostListPage`는 전체 목록 화면을 담당합니다.

`PostCard`는 게시글 카드 하나를 담당합니다.

`Pagination`은 이전/다음 버튼과 페이지 정보를 담당합니다.

## 정적 페이지에서 사용할 임시 데이터

정적 화면 확인을 위해 아래처럼 임시 데이터를 사용할 수 있습니다.

```
postId
title
authorNickname
createdAt
likeCount
commentCount
viewCount
blinded
```

예를 들어 카드에는 아래 정보가 보여야 합니다.

```
게시글 제목
작성자
작성일
Star 수
Thread 수
View 수
```

## 아직 구현하지 않을 기능

정적 페이지 단계에서는 아래 기능을 아직 구현하지 않습니다.

```
- 실제 게시글 목록 API 조회
- 페이지네이션 API 요청
- 게시글 클릭 시 상세 페이지 이동
- Login 버튼 클릭 이동
- Commit 버튼 클릭 이동
- Latest / Hot 정렬 기능
- 로그인 여부에 따른 버튼 표시 변경
- 블라인드 게시글 클릭 제한
```

## 완료 조건

```
- 게시글 목록 화면이 보입니다.
- 소개 문구가 보입니다.
- Commit 버튼이 보입니다.
- Latest / Hot 버튼이 보입니다.
- 임시 게시글 카드가 최소 1개 이상 보입니다.
- 카드 안에 제목, 작성자, 날짜, Star, Thread, View 정보가 보입니다.
- 이전/다음 페이지 버튼이 보입니다.
```

![image.png](PostListPage%20%EC%A0%95%EC%A0%81%20%ED%8E%98%EC%9D%B4%EC%A7%80/image.png)

신고처리 된 게시글까지 mock으로 보여주었습니다