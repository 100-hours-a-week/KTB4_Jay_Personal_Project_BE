# PostDetailPage 정적 페이지

## 기존 기준 파일

```
vanilla-js-frontend/html/posts.html
```

기존 section:

```
post-detail-section
```

## 화면 목적

PostDetailPage는 게시글 하나의 상세 정보를 보여주는 화면입니다.

기존에서는 게시글 상세 API를 호출해서 제목, 작성자, 본문, 좋아요 수, 댓글 등을 표시했습니다.

정적 페이지 단계에서는 API를 연결하지 않고 임시 게시글 데이터를 사용해서 화면 구조만 만듭니다.

## 화면에 보여야 하는 요소

```
- 게시글 제목
- Bug Report 버튼
- Back to Feed 버튼
- 작성자
- 작성일
- 수정됨 표시 영역
- 게시글 본문
- View 수
- Star 수
- Thread 수
- Star 버튼
- Amend 버튼
- Drop 버튼
- 신고 입력 박스
- Thread 제목
- 댓글 목록
- 댓글 입력창
- Review 버튼
```

기존 HTML 기준으로는 아래 id/class를 참고합니다.

```
post-detail-section
detail-title
show-report-button
back-to-list-button
detail-author
detail-created-at
detail-edited
detail-content
detail-view-count
detail-like-count
detail-comment-count
like-post-button
show-edit-button
delete-post-button
report-box
report-reason-input
report-post-button
comment-list
comment-input
create-comment-button
```

## 컴포넌트 분리

React에서는 아래처럼 나눕니다.

```
PostDetailPage.jsx
CommentList.jsx
CommentItem.jsx
```

`PostDetailPage`는 게시글 상세 전체 화면을 담당합니다.

`CommentList`는 댓글 목록을 담당합니다.

`CommentItem`은 댓글 하나를 담당합니다.

## 정적 페이지에서 사용할 임시 데이터

게시글 상세 화면 확인을 위해 임시 데이터가 필요합니다.

```
title
authorNickname
createdAt
edited
content
viewCount
likeCount
commentCount
liked
comments
```

댓글에는 아래 정보가 있으면 됩니다.

```
commentId
authorNickname
createdAt
content
replies
```

## 아직 구현하지 않을 기능

정적 페이지 단계에서는 아래 기능을 아직 구현하지 않습니다.

```
- 게시글 상세 API 조회
- 좋아요 API 요청
- 신고 API 요청
- 게시글 수정 페이지 이동
- 게시글 삭제 API 요청
- 댓글 작성 API 요청
- 댓글 수정 API 요청
- 댓글 삭제 API 요청
- 작성자 여부에 따른 버튼 표시 변경
- 신고 입력창 열기/닫기
```

## 완료 조건

```
- 게시글 제목이 보입니다.
- 작성자와 작성일이 보입니다.
- 게시글 본문이 보입니다.
- View, Star, Thread 숫자가 보입니다.
- Star, Amend, Drop, Bug Report 버튼이 보입니다.
- 댓글 목록이 보입니다.
- 댓글 입력창과 Review 버튼이 보입니다.
- 임시 댓글이 최소 1개 이상 보입니다.
```

![image.png](PostDetailPage%20%EC%A0%95%EC%A0%81%20%ED%8E%98%EC%9D%B4%EC%A7%80/image.png)