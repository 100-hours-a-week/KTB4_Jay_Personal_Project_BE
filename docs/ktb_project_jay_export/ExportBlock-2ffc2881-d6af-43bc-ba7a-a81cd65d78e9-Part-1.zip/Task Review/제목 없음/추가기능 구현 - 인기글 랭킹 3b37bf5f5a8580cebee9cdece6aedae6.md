# 추가기능 구현 - 인기글 랭킹

현재는 Scheduled를 사용하여서 진행중 → Spring batch로 전환 

# Scheduled vs Spring batch

## 1. 트랜잭션 범위와 메모리 문제

### `@Scheduled` 방식

데이터가 적지만 데이터가 많아지면 **OOM 문제가 발생**하거나 하나의 거대한 트랜잭션으로 묶여서 **DB 락 및 대기 지연** 발생

### Spring Batch

데이터를 통째로 가져오는게 아니라 조금씩 나눠서 가져와서 

- ItemReader: 읽기
- ItemProcessor: 계산하기
- ItemWriter: DB에 쓰기

작업을 반복, 메모리 사용량이 일정하게 유지되며, 트랜잭션도 Chunk 단위로 나누어 커밋되어서 DB 부담이 훨씬 줄어듦

---

## 예외 발생 시의 안전장치

### `@Scheduled` 방식

- 5분마다 돌다가 실패하면 배치 작업 전체 실패하고 중단됨
- 당연히 어디까지 진행되었는지 기록이 남지 않아서 다음 5분뒤에 처음부터 전체 작업을 다 실행

### Spring Batch

- 메타 데이터 테이블 관리: 배치 실행될 때마다 `BATCH_JOB_EXECUTION`,`BATCH_STEP_EXECUTION`  전용 테이블에 실행결과 실패 지점 처리 건수 자동으로 기록
- 재시도 및 건너 뛰기: 중간에 1건이 에러 나더라도 해당 건만 Skip 하거나 작업이 실패 했을 때 실패한 지점부터 다시 시작할 수 있는 복구 메커니즘 제공

---

## 서버 수평 확장 시 중복 실행 문제

### `@Scheduled` 방식

- 애플리케이션 서버가 2대 이상으로 늘리게 되면 각 서버마다 `@Scheduled` 타이머 각각 동작해서 중복으로 랭킹 계산 로직 실행
- ShedLock 같은 별도의 distributed lock 라이브러리 추가해야 함.

### Spring Batch

- 배치 실행 전용 서버나 별도의 분리된 스케줄러와 연동하여 배치 애플리케이션 독립적인 프로세스로 분리 가능.

---

## 비즈니스 로직과 대주기/ 대용량 책임 분리

### `@Scheduled` 방식

- 웹 요청을 처리하는 웹 서버 내부에 주기적인 데이터 집계 로직이 섞여 들어갑니다.
- 5분마다 집계 작업 돌아가는 동안 CPU나 DB Connection Pool 많이 잡아 먹으면 실제 유저들의 API 요청 속도 느려지는 악영향 받을 수 있음

### Spring Batch

- 사용자의 요청 받아서 빠르게 응답하는 API 애플리케이션과 대용량 데이터 주도적으로 처리하는 Batch 애플리케이션의 책임을 분리할 수 있음.

---

## 스케쥴러들은 뭐가 있음

### 1. Quartz Scheduler

서버가 여러 대여도 한 곳에서만 실행되도록 제어해 줌.

스프링과 아주 잘 연동되는 전문 스케줄링 라이브러리

### 2. 외부 운영체제 / CI/CD 스케줄러

- Linux Cron: 리눅스 OS 자체에서 제공하는 주기적 실행 기능
- Jenkins/ Airflow: CI/CD 및 대용량 데이터 파이프라인 관리 도구

일단 스프링 배치 + RDB로 접근 정함.

# 2. 스프링 배치 이용

## 1. 의존성 추가

```groovy
implementation 'org.springframework.boot:spring-boot-starter-batch'
```

## 2. yml 파일 수정

```yaml
batch:
  job:
    enabled: false
  jdbc:
    initialize-schema: always
```

job:
      enabled: false

- 애플리케이션 시작시 batch job 자동 실행되는 것 막기
- 5분마다 직접 `joblauncher`로 실행
    
    jdbc:
          initialize-schema: always
    
- 스프링 배치 메타 테이블 자동 생성
- `BATCH_JOB_INSTANCE`, `BATCH_JOB_EXECUTION` 같은 테이블

## 3. @Scheduled 제거

원래 @Scheduled 를 통해 5분마다 RankingBatchService에서 반복을 진행하였는데,

이제 스케쥴러는 알람 기능만 하고 spring batch를 통해서 배치 진행하는 것으로 바꾸었습니다.

제거보다는 스프링 배치로 옮겨준 것, RankingBatchService는 삭제하고 insert하는 기능만 남겨둠.

# 3. ShedLock 구현

문제가 멀티 인스턴스에서 어떻게 스프링 배치를 구현할 것인지였습니다.

### 단일 인스턴스

단일 인스턴스일 때는 문제가 되지 않습니다. 그냥 5분마다 배치 진행해서 처리하면 됩니다.

### 멀티 인스턴스

하지만 멀티 인스턴스일 때는 문제가 발생합니다. 서로 다른 애플리케이션 서버에서 동시에 배치 요청을 보내게 되면 분산 락 문제가 걸릴 수도 잇고 중복 문제도 발생할 수 있습니다

따라서 해결책으로 ShedLock이랑 Redis를 고려하였습니다.

### ShedLock

장점

- 인프라를 늘릴 필요가 없다.
    - 기존에 있는 RDB안에 ShedLock 테이블을 만들어서 구현이 가능
- 락 상태를 테이블로 확인이 가능

단점

- DB에 락 요청 추가
- 고빈도 락에는 부담

### Redis 기반 분산 락

장점

- 락 처리 빠름
- 멀티 인스턴스 환경에 적합
- 기존에 채팅에서 사용하고 있다면 재사용 가능?

단점

- Redis 장애 고려 필요
- 안정성 고려
- 인프라를 늘려서 Redis 서버 관리 필요

여러가지 고려하고 kevin과 상의 끝에 ShedLock으로 가서 고도화하는 작업을 먼저 고려했습니다.

멀티인스턴스 환경에서 **각 서버의 스케줄러가 동시에 Spring Batch Job을 실행하는 문제를 재현**하고,JDBC 기반 **ShedLock과 업무 기준 JobParameter를 적용해 단일 실행을 보장**했습니다. 또한 결과 테이블의 **유니크 제약과 멱등 저장**을 통해 락 만료나 재실행 상황에서도 **랭킹 데이터가 중복되지 않도록** 설계했습니다.

# 4. ShedLock

## 1. 의존성 추가

```groovy
implementation 'net.javacrumbs.shedlock:shedlock-spring:7.7.0'
implementation 'net.javacrumbs.shedlock:shedlock-provider-jdbc-template:7.7.0'
```

## 2. ShedLock 테이블 추가

![image.png](%EC%B6%94%EA%B0%80%EA%B8%B0%EB%8A%A5%20%EA%B5%AC%ED%98%84%20-%20%EC%9D%B8%EA%B8%B0%EA%B8%80%20%EB%9E%AD%ED%82%B9/image.png)

```sql
CREATE TABLE shedlock (
    name VARCHAR(64) NOT NULL,
    lock_until TIMESTAMP NOT NULL,
    locked_at TIMESTAMP NOT NULL,
    locked_by VARCHAR(255) NOT NULL,
    PRIMARY KEY (name)
);
```

테이블 추가

```sql
name        어떤 스케줄 락인지
lock_until  언제까지 락이 유효한지
locked_at   언제 락을 잡았는지
locked_by   어떤 서버가 락을 잡았는지
```

## 3. Config 설정

```java
package kr.adapterz.springboot.global.config;

import net.javacrumbs.shedlock.core.LockProvider;
import net.javacrumbs.shedlock.provider.jdbctemplate.JdbcTemplateLockProvider;
import net.javacrumbs.shedlock.spring.annotation.EnableSchedulerLock;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;

@Configuration
@EnableSchedulerLock(defaultLockAtMostFor = "PT10M")
public class ShedLockConfig {

    @Bean
    public LockProvider lockProvider(DataSource dataSource) {
        return new JdbcTemplateLockProvider(
                JdbcTemplateLockProvider.Configuration.builder()
                        .withJdbcTemplate(new JdbcTemplate(dataSource))
                        .usingDbTime()
                        .build()
        );
    }
}
```

`usingDbTime()` 를 활용해서 서버 시간이 아니라 DB시간으로 처리

## 4. `@SchedulerLock` 추가

```java
@SchedulerLock(
        name = "postRankingJob",
        lockAtMostFor = "PT4M",
        lockAtLeastFor = "PT30S"
)
```

- 아무리 죽거나 락 해제를 못해도 최대 4분 뒤에는 뒤에 사람 쓸 수 있게 푸셈..
- 아무리 빨리 끝나도 30초는 유지하고 있어

# 5. 다중 인스턴스 테스트

![image.png](%EC%B6%94%EA%B0%80%EA%B8%B0%EB%8A%A5%20%EA%B5%AC%ED%98%84%20-%20%EC%9D%B8%EA%B8%B0%EA%B8%80%20%EB%9E%AD%ED%82%B9/image%201.png)

8080, 8081 포트 두개에 실행해서 락이 걸리는지 테스트 했습니다.

![image.png](%EC%B6%94%EA%B0%80%EA%B8%B0%EB%8A%A5%20%EA%B5%AC%ED%98%84%20-%20%EC%9D%B8%EA%B8%B0%EA%B8%80%20%EB%9E%AD%ED%82%B9/image%202.png)

문제가 lockAtLeastFor이 너무 짧아서 실행이 5분마다 되는게 아니라 겹쳐서 되는 것이였습니다.

1. lockAtLeastFor을 늘린다.
2. JobParameter를 millis에서 runSlot으로 바꾼다.

```java
public void runPostRankingJob() {
        try {
            LocalDateTime now = LocalDateTime.now();
            LocalDateTime runSlot = now
                    .withMinute(now.getMinute() / 5 * 5)
                    .withSecond(0)
                    .withNano(0);

            JobParameters jobParameters = new JobParametersBuilder()
                    .addString("requestTime", runSlot.toString())
                    .toJobParameters();

            log.info("Post ranking batch job started");
            jobLauncher.run(postRankingJob, jobParameters);
            log.info("Post ranking batch job finished");
        } catch (Exception e) {
            log.error("Post ranking batch job failed", e);
        }
    }
```

따로 시간을 줄이기 보다는 시간을 정시로 맞춰서 

6분 → 5분

12분 → 10분으로 

5분마다 JobParameter를 맞춰주었습니다.

![image.png](%EC%B6%94%EA%B0%80%EA%B8%B0%EB%8A%A5%20%EA%B5%AC%ED%98%84%20-%20%EC%9D%B8%EA%B8%B0%EA%B8%80%20%EB%9E%AD%ED%82%B9/image%203.png)

5분마다 나오기 성공!!

# 6. 회고

음.. 일단 다중 인스턴스를 포트를 다르게 해서 구현했는데 실제 운영 장애를 직접 발견하지는 못하였습니다..

기존 랭킹 시스템은 `@Scheduled` 를 이용해서 5분마다 실행되는 구조였습니다. 단일 인스턴스에서는 문제가 없지만 멀티 인스턴스로 전환시 각 서버의 스케줄러가 동시에 실행될 수 잇는 문제가 발생했습니다.

만약 백엔드 인스턴스가 2개라면 두 서버 모두 같은 spring 애플리케이션을 실행하여서 동일한 `@Scheduled메서드가 동작합니다.` 그러면 인기글 랭킹 배치가 중복 실행될 수 있고 불필요한 DB 작업이 반복되거나 데이터 정합성 문제가 발생할 수 있다고 판단하였습니다.

이를 바탕으로 Spring Batch 기반으로 리팩토링 진행하였습니다.

`@Scheduled` 는 그대로 유자하지만 직접 랭킹 갱신 로직을 실행하지는 않고, JobLauncher를 통해 Spring Batch Job 을 실행하도록 변경하였습니다. 

여기서 Redis Sorted Set 처럼 랭킹 저장소를 바꾸는 방식도 있었지만 현재 저의 프로젝트 서비스 규모에서는 그정도의 실시간성과 고성능 랭킹 처리는 필요하지 않다고 판단하였습니다. 이에 기존 RDB 기반 랭킹 테이블을 유지하고 배치 실행구조, 중복 실행 방어에 집중했습니다.

멀티 인스턴스 환경에서 중복 실행 방지하기 위해서 JDBC 기반 ShedLock을 적용했습니다.

shedlock 테이블을 통해 여러 서버 중 하나의 서버만 스케줄러 락을 획득하도록 보장하여 모든 서버의 스케쥴드가 깨어나지만 실제 Spring Batch Job은 락을 획득한 하나의 서버에서만 실행됩니다.

처음에는 JobParameter에 currentTimeMillis()를 사용하였는데 이 방식은 매번 다른 JobInstance를 생성합니다. 결국 밀리 세컨드 단위기 때문에 Spring Batch 가 다른 Job이라고 인식. 그래서 5분 실행 구간을 하나의 배치 실행 단위로 식별하게 runSlot 개념을 적용해서 5분동안 발생한 배치는 전부 하나의 슬롯으로 묶어서 같은 JobInstance로 인식하게 했습니다.

@Scheduled

- 5분마다 배치 실행 트리거

ShedLock

- 여러 서버 중 하나만 스케줄러 실행

Spring Batch JobParameter(runSlot)

- 같은 5분 구간의 실행을 같은 JobInstance로 식별

post_rankings unique 제약

- 같은 기간, 같은 게시글 랭킹의 중복 저장 방지

delete 후 insert 방식

- 같은 배치가 재실행되더라도 최종 결과가 동일하도록 멱등성 유지

이번 Spirng Batch + Shedlock은 그냥 옮기는 것보다 멀티 인스턴스 환경에서 배치가 어떻게 실행되는지에 중점을 두고 중복 실행을 어떻게 방어해야 하는지 고민할 수 있었습니다. 

- Batch 의 실행 단위 식별을 위한 JobParameter 설정
- DB unique 제약
- ShedLock의 동시 실행 방지

이 방식들이 각 계층의 역할에서 방어해주는 것을 알게 되었습니다.

chunk 단위로 나눠서 하다가 api 속도가 좀 느려질 수도 있지 않을까?