# API 초기 설계 (1)

# 필요한 도메인

```java
1. user (회원 정보 처리)
2. post (게시글 관련 처리)
3. comment (댓글 관리)
4. like (좋아요 관리)
5. report (신고 관리)
```

# 1. User

## field

| Name | Type |
| --- | --- |
| email | String |
| password | String |
| id | Long |
| profileImage | String |
| deleted | Boolean |
| nickname | String |

## 기능

| Request Method | Content |
| --- | --- |
| POST | 회원가입 |
| POST | 로그인 |
| PATCH | 회원정보 수정 (nickname, profileImage) |
| DELETE | 회원 탈퇴 |
| PATCH | 회원 비밀번호 수정 |

---

# 2. post

## field

| Name | Type |
| --- | --- |
| id | Long |
| title | String |
| content | String |
| authorId | Long |
| createdAt | String |
| updatedAt | String |
| edited | Boolean |
| deleted | Boolean |
| blinded | Boolean |
| viewCount | Long |
| likeCount | Long |
| reportCount | Long |

## 기능

| Request Method | Content |
| --- | --- |
| POST | 게시글 작성 |
| GET | 게시글 목록 조회 |
| PATCH | 게시글 수정 |
| DELETE | 게시글 삭제 |
| GET | 게시글 상세조회 |

---

# 3. comment

## field

| Name | Type |
| --- | --- |
| id | Long |
| postId | Long |
| authorId | Long |
| content | String |
| deleted | Boolean |
| createdAt | String |
| updatedAt | String |

## 기능

| Request Method | Content |
| --- | --- |
| POST | 댓글 작성 |
| PATCH | 댓글 수정 |
| DELETE | 댓글 삭제 |

---

# 4. like

## field

| Name | Type |
| --- | --- |
| userId | Long |
| postId | Long |

## 기능

| Request Method | Content |
| --- | --- |
| POST | 회원가입 |
| POST | 로그인 |
| PATCH | 회원정보 수정 (nickname, profileImage) |
| DELETE | 회원 탈퇴 |
| PATCH | 회원 비밀번호 수정 |

---

# 5. report

## field

| Name | Type |
| --- | --- |
| postId | Long |
| userId | Long |
| reason | String |
| createdAt | String |

## 기능

| Request Method | Content |
| --- | --- |
| POST | 신고 |