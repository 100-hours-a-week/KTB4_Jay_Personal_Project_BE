# Postman 요청 응답 자료

# 1. User

## 1. 회원가입 요청

### 성공

![image.png](Postman%20%EC%9A%94%EC%B2%AD%20%EC%9D%91%EB%8B%B5%20%EC%9E%90%EB%A3%8C/image.png)

### 동일 이메일 or 닉네임 요청

![image.png](Postman%20%EC%9A%94%EC%B2%AD%20%EC%9D%91%EB%8B%B5%20%EC%9E%90%EB%A3%8C/image%201.png)

### 비어있는 이메일 or 닉네임 or 비밀번호 요청

![image.png](Postman%20%EC%9A%94%EC%B2%AD%20%EC%9D%91%EB%8B%B5%20%EC%9E%90%EB%A3%8C/image%202.png)

---

## 2. 로그인 요청

### 성공

![image.png](Postman%20%EC%9A%94%EC%B2%AD%20%EC%9D%91%EB%8B%B5%20%EC%9E%90%EB%A3%8C/image%203.png)

### 로그인 요청 시 이메일이 비어있는 경우

![image.png](Postman%20%EC%9A%94%EC%B2%AD%20%EC%9D%91%EB%8B%B5%20%EC%9E%90%EB%A3%8C/image%204.png)

---

## 3. 회원정보 수정

### 성공

![image.png](Postman%20%EC%9A%94%EC%B2%AD%20%EC%9D%91%EB%8B%B5%20%EC%9E%90%EB%A3%8C/image%205.png)

### 이미 존재하는 닉네임

![image.png](Postman%20%EC%9A%94%EC%B2%AD%20%EC%9D%91%EB%8B%B5%20%EC%9E%90%EB%A3%8C/image%206.png)

---

## 회원 정보 삭제

### 성공

![image.png](Postman%20%EC%9A%94%EC%B2%AD%20%EC%9D%91%EB%8B%B5%20%EC%9E%90%EB%A3%8C/image%207.png)

![image.png](Postman%20%EC%9A%94%EC%B2%AD%20%EC%9D%91%EB%8B%B5%20%EC%9E%90%EB%A3%8C/image%208.png)

---

## 회원 비밀번호 수정

### 성공

![image.png](Postman%20%EC%9A%94%EC%B2%AD%20%EC%9D%91%EB%8B%B5%20%EC%9E%90%EB%A3%8C/image%209.png)

---

# 2. Post

## 게시글 작성

### 성공

![image.png](Postman%20%EC%9A%94%EC%B2%AD%20%EC%9D%91%EB%8B%B5%20%EC%9E%90%EB%A3%8C/image%2010.png)

---

## 목록 조회

### 성공

![image.png](Postman%20%EC%9A%94%EC%B2%AD%20%EC%9D%91%EB%8B%B5%20%EC%9E%90%EB%A3%8C/image%2011.png)

### 탈퇴한 사용자의 게시글인 경우

![image.png](Postman%20%EC%9A%94%EC%B2%AD%20%EC%9D%91%EB%8B%B5%20%EC%9E%90%EB%A3%8C/image%2012.png)

### 신고 누적으로 가려진 사용자의 경우

---

## 게시글 삭제

### 성공

![image.png](Postman%20%EC%9A%94%EC%B2%AD%20%EC%9D%91%EB%8B%B5%20%EC%9E%90%EB%A3%8C/image%2013.png)

![image.png](Postman%20%EC%9A%94%EC%B2%AD%20%EC%9D%91%EB%8B%B5%20%EC%9E%90%EB%A3%8C/image%2014.png)

---

## 게시글 수정

### 성공

![image.png](Postman%20%EC%9A%94%EC%B2%AD%20%EC%9D%91%EB%8B%B5%20%EC%9E%90%EB%A3%8C/image%2015.png)

---

## 게시글 상세조회

### 성공

![image.png](Postman%20%EC%9A%94%EC%B2%AD%20%EC%9D%91%EB%8B%B5%20%EC%9E%90%EB%A3%8C/image%2016.png)

---

# 3. Comment

## 댓글 작성

### 성공

![image.png](Postman%20%EC%9A%94%EC%B2%AD%20%EC%9D%91%EB%8B%B5%20%EC%9E%90%EB%A3%8C/image%2017.png)

## 댓글 수정

### 성공

![image.png](Postman%20%EC%9A%94%EC%B2%AD%20%EC%9D%91%EB%8B%B5%20%EC%9E%90%EB%A3%8C/image%2018.png)

## 댓글 삭제

### 성공

![image.png](Postman%20%EC%9A%94%EC%B2%AD%20%EC%9D%91%EB%8B%B5%20%EC%9E%90%EB%A3%8C/image%2019.png)

- 삭제 했을 때 상세조회

![image.png](Postman%20%EC%9A%94%EC%B2%AD%20%EC%9D%91%EB%8B%B5%20%EC%9E%90%EB%A3%8C/image%2020.png)

**대댓글 안사라짐**

---

# 4. Reply

## 대댓글 작성

### 성공

![image.png](Postman%20%EC%9A%94%EC%B2%AD%20%EC%9D%91%EB%8B%B5%20%EC%9E%90%EB%A3%8C/image%2021.png)

## 대댓글 수정

### 성공

![image.png](Postman%20%EC%9A%94%EC%B2%AD%20%EC%9D%91%EB%8B%B5%20%EC%9E%90%EB%A3%8C/image%2022.png)

---

# 5. Like

## 좋아요 누르기

### 성공

![image.png](Postman%20%EC%9A%94%EC%B2%AD%20%EC%9D%91%EB%8B%B5%20%EC%9E%90%EB%A3%8C/image%2023.png)

## 좋아요 취소

### 성공

![image.png](Postman%20%EC%9A%94%EC%B2%AD%20%EC%9D%91%EB%8B%B5%20%EC%9E%90%EB%A3%8C/image%2024.png)