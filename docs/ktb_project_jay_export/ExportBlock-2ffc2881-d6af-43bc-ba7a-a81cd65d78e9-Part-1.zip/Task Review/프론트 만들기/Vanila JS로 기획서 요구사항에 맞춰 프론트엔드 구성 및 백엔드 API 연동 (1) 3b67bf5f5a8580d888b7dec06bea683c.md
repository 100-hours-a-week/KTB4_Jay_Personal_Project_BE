# Vanila JS로 기획서 요구사항에 맞춰 프론트엔드 구성 및 백엔드 API 연동 (1)

일단 감이 아예 안잡혀서 게시글 HTML, CSS, JS 코드의 구조를 알려달라고 했습니다.

→ 결과를 통해 코드를 이해하고 이해한 코드를 바탕으로 나머지 기능을 수행하는 것이 제 목표였습니다.

# Post

## HTML/ CSS

- HTML 코드
    
    ```html
    <h1>게시판</h1>
    
    <button id="show-list-button">목록</button>
    <button id="show-create-button">글쓰기</button>
    
    <p id="global-message"></p>
    
    <section id="post-list-section">
      <div>
        <h2>게시글 목록</h2>
        <button id="refresh-posts-button">새로고침</button>
      </div>
    
      <div id="post-list"></div>
    </section>
    
    <section id="post-create-section" class="hidden">
      <h2>게시글 작성</h2>
    
      <input id="create-title-input" type="text" placeholder="제목" />
      <textarea id="create-content-input" placeholder="내용"></textarea>
    
      <button id="create-post-button">작성하기</button>
    </section>
    
    <script src="./app.js"></script>
    ```
    

<aside>
💡

**HTML 코드에서 알아야 하는것**

1. id 값은 JS가 찾아가기 위한 주소이다.
2. 처음에 안보이는 화면은 `hidden` 클래스를 붙였다 떼서 조정한다.
3. `div` 는 화면의 구역을 만드는 박스인데 `div` 만 있으면 JS가 못 찾기 때문에
    
    → 이름표(id)를 붙여줍니다.
    

```html
<div id="post-list"></div>
```

→ 이 div 의 이름은 post-list이고 여기에 게시글 목록 넣을 상자입니다.

</aside>

- CSS 코드
    
    ```css
    body {
      font-family: sans-serif;
      margin: 0;
      background-color: #f5f6f8;
    }
    
    button {
      padding: 10px 14px;
      border: none;
      border-radius: 8px;
      background-color: #222;
      color: white;
      cursor: pointer;
    }
    
    section {
      max-width: 800px;
      margin: 40px auto;
      padding: 24px;
      background-color: white;
      border: 1px solid #ddd;
      border-radius: 12px;
    }
    
    .hidden {
      display: none;
    }
    
    .post-card {
      padding: 16px;
      margin-top: 12px;
      border: 1px solid #ddd;
      border-radius: 10px;
      cursor: pointer;
    }
    
    .post-card:hover {
      background-color: #f2f2f2;
    }
    
    .error {
      color: red;
      font-weight: bold;
    }
    
    .success {
      color: green;
      font-weight: bold;
    }
    ```
    

## JS

```jsx
const API_BASE_URL = "http://localhost:8080";

const globalMessage = document.querySelector("#global-message");
const postList = document.querySelector("#post-list");
const refreshPostsButton = document.querySelector("#refresh-posts-button");

function showMessage(message, type) {
  globalMessage.textContent = message;

  globalMessage.classList.remove("success");
  globalMessage.classList.remove("error");

  if (type === "success") {
    globalMessage.classList.add("success");
  }

  if (type === "error") {
    globalMessage.classList.add("error");
  }
}

async function loadPosts() {
  try {
    showMessage("게시글 목록을 불러오는 중입니다.", "success");

    const response = await fetch(`${API_BASE_URL}/posts`);

    if (!response.ok) {
      throw new Error("게시글 목록 조회에 실패했습니다.");
    }

    const result = await response.json();

    const posts = result.data;

    renderPosts(posts);

    showMessage("게시글 목록을 불러왔습니다.", "success");
  } catch (error) {
    showMessage(error.message, "error");
  }
}

function renderPosts(posts) {
  postList.innerHTML = "";

  if (posts.length === 0) {
    postList.innerHTML = "<p>게시글이 없습니다.</p>";
    return;
  }

  posts.forEach(function (post) {
    const postCard = document.createElement("div");

    postCard.classList.add("post-card");

    postCard.textContent = post.title;

    postList.appendChild(postCard);
  });
}

refreshPostsButton.addEventListener("click", function () {
  loadPosts();
});

loadPosts();
```

![image.png](Vanila%20JS%EB%A1%9C%20%EA%B8%B0%ED%9A%8D%EC%84%9C%20%EC%9A%94%EA%B5%AC%EC%82%AC%ED%95%AD%EC%97%90%20%EB%A7%9E%EC%B6%B0%20%ED%94%84%EB%A1%A0%ED%8A%B8%EC%97%94%EB%93%9C%20%EA%B5%AC%EC%84%B1%20%EB%B0%8F%20%EB%B0%B1%EC%97%94%EB%93%9C%20API%20%EC%97%B0%EB%8F%99%20(1)/image.png)

처음에는 코드를 그대로 받아서 `게시글 목록`, `글쓰기`, `새로고침` 을 만들었습니다.

전혀 감이 잡히지 않아 코드 한 줄, 한줄 설명을 요청하였습니다.

### fetch

JS에서 fetch를 통해 백엔드 API로 HTTP 요청을 보냅니다.

여기서 왜 fetch만 썼는데 GET이 나가는지 궁금했는데 

```jsx
fetch("http://localhost:8080/posts")
```

기본값이 GET이고 만약 다른 요청을 보내고 싶으면

```jsx
fetch("http://localhost:8080/posts", {
  method: "GET"
});
```

method를 설정해야 함을 알게 되었습니다.

연결 후에 게시글 목록 버튼을 눌러보았는데 

![image.png](Vanila%20JS%EB%A1%9C%20%EA%B8%B0%ED%9A%8D%EC%84%9C%20%EC%9A%94%EA%B5%AC%EC%82%AC%ED%95%AD%EC%97%90%20%EB%A7%9E%EC%B6%B0%20%ED%94%84%EB%A1%A0%ED%8A%B8%EC%97%94%EB%93%9C%20%EA%B5%AC%EC%84%B1%20%EB%B0%8F%20%EB%B0%B1%EC%97%94%EB%93%9C%20API%20%EC%97%B0%EB%8F%99%20(1)/image%201.png)

다음 오류가 나왔습니다. 딥다이브 때 팠던 `CORS` 에러여서 서버에 해당 요청을 허용하는 코드를 만들었습니다.

```java
package kr.adapterz.springboot.global.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOrigins(
                        "http://127.0.0.1:5500",
                        "http://localhost:5500"
                )
                .allowedMethods("GET", "POST", "PATCH", "PUT", "DELETE", "OPTIONS")
                .allowedHeaders("*");
    }
} 
```

Origin에 *이 아니라 일단 프론트 주소를 썼고, Method 및 Headers에 알맞게 썼습니다.

![image.png](Vanila%20JS%EB%A1%9C%20%EA%B8%B0%ED%9A%8D%EC%84%9C%20%EC%9A%94%EA%B5%AC%EC%82%AC%ED%95%AD%EC%97%90%20%EB%A7%9E%EC%B6%B0%20%ED%94%84%EB%A1%A0%ED%8A%B8%EC%97%94%EB%93%9C%20%EA%B5%AC%EC%84%B1%20%EB%B0%8F%20%EB%B0%B1%EC%97%94%EB%93%9C%20API%20%EC%97%B0%EB%8F%99%20(1)/image%202.png)

그 결과 CORS 에러는 없어졌고 아직 게시글 목록이 없어서 아무런 게시글을 반환하지 못한 채 응답이 마무리 되었습니다.

## 게시글 목록

일단은 게시글을 만드는게 목적이여서 H2 DB에 더미 데이터를 넣어보았습니다.

H2 - console 창에 user, post를 각각 더미데이터 하나씩 만들었습니다.

**user**

- 가짜 유저 데이터 삽입
    
    ```sql
    INSERT INTO users (
        email,
        password,
        nickname,
        profile_image,
        deleted_at
    ) VALUES
    (
        'test1@test.com',
        '1234',
        '테스트유저1',
        null,
        null
    ),
    (
        'test2@test.com',
        '1234',
        '테스트유저2',
        null,
        null
    );
    ```
    

![image.png](Vanila%20JS%EB%A1%9C%20%EA%B8%B0%ED%9A%8D%EC%84%9C%20%EC%9A%94%EA%B5%AC%EC%82%AC%ED%95%AD%EC%97%90%20%EB%A7%9E%EC%B6%B0%20%ED%94%84%EB%A1%A0%ED%8A%B8%EC%97%94%EB%93%9C%20%EA%B5%AC%EC%84%B1%20%EB%B0%8F%20%EB%B0%B1%EC%97%94%EB%93%9C%20API%20%EC%97%B0%EB%8F%99%20(1)/image%203.png)

**post**

- 가짜 게시글 데이터 삽입
    
    ```sql
    INSERT INTO posts (
        author_id,
        title,
        content,
        view_count,
        like_count,
        comment_count,
        blinded,
        created_at,
        updated_at,
        deleted_at
    ) VALUES
    (
        1,
        '첫 번째 게시글',
        '첫 번째 게시글 내용입니다.',
        0,
        0,
        0,
        false,
        CURRENT_TIMESTAMP,
        null,
        null
    ),
    (
        1,
        '두 번째 게시글',
        '두 번째 게시글 내용입니다.',
        0,
        0,
        0,
        false,
        CURRENT_TIMESTAMP,
        null,
        null
    ),
    (
        2,
        '세 번째 게시글',
        '세 번째 게시글 내용입니다.',
        0,
        0,
        0,
        false,
        CURRENT_TIMESTAMP,
        null,
        null
    );
    ```
    

![image.png](Vanila%20JS%EB%A1%9C%20%EA%B8%B0%ED%9A%8D%EC%84%9C%20%EC%9A%94%EA%B5%AC%EC%82%AC%ED%95%AD%EC%97%90%20%EB%A7%9E%EC%B6%B0%20%ED%94%84%EB%A1%A0%ED%8A%B8%EC%97%94%EB%93%9C%20%EA%B5%AC%EC%84%B1%20%EB%B0%8F%20%EB%B0%B1%EC%97%94%EB%93%9C%20API%20%EC%97%B0%EB%8F%99%20(1)/image%204.png)

![image.png](Vanila%20JS%EB%A1%9C%20%EA%B8%B0%ED%9A%8D%EC%84%9C%20%EC%9A%94%EA%B5%AC%EC%82%AC%ED%95%AD%EC%97%90%20%EB%A7%9E%EC%B6%B0%20%ED%94%84%EB%A1%A0%ED%8A%B8%EC%97%94%EB%93%9C%20%EA%B5%AC%EC%84%B1%20%EB%B0%8F%20%EB%B0%B1%EC%97%94%EB%93%9C%20API%20%EC%97%B0%EB%8F%99%20(1)/image%205.png)

그 결과 카드에 첫 번째 게시글이 들어갔습니다!!

## 상세 조회

게시글 카드는 나왔으니 해당 카드 제목을 누르면 상세 조회가 나오도록 바꿨습니다.

```jsx
postCard.addEventListener("click", function () {
        console.log(post.postId);
    });
```

먼저 게시글 목록에서 상세조회를 눌렀을 때 이벤트 처리를 하였습니다.

---

감이 안잡혀서 일단 HTML, CSS 코드를 전부 받고 JS와 함께 코드를 이해해보려고 했습니다.

그런데 자꾸 오류가 나서 봤더니 app.js에서 url 매핑을 안해주어서 매핑을 모두 완료했습니다.

JS 코드는 게시글 기능까지 ai 도움을 받으며 문법과 사용 방법등을 물어보았습니다.

[현재 시점 코드](Vanila%20JS%EB%A1%9C%20%EA%B8%B0%ED%9A%8D%EC%84%9C%20%EC%9A%94%EA%B5%AC%EC%82%AC%ED%95%AD%EC%97%90%20%EB%A7%9E%EC%B6%B0%20%ED%94%84%EB%A1%A0%ED%8A%B8%EC%97%94%EB%93%9C%20%EA%B5%AC%EC%84%B1%20%EB%B0%8F%20%EB%B0%B1%EC%97%94%EB%93%9C%20API%20%EC%97%B0%EB%8F%99%20(1)/%ED%98%84%EC%9E%AC%20%EC%8B%9C%EC%A0%90%20%EC%BD%94%EB%93%9C%202f77bf5f5a8583d39b34012904b24024.md)

![image.png](Vanila%20JS%EB%A1%9C%20%EA%B8%B0%ED%9A%8D%EC%84%9C%20%EC%9A%94%EA%B5%AC%EC%82%AC%ED%95%AD%EC%97%90%20%EB%A7%9E%EC%B6%B0%20%ED%94%84%EB%A1%A0%ED%8A%B8%EC%97%94%EB%93%9C%20%EA%B5%AC%EC%84%B1%20%EB%B0%8F%20%EB%B0%B1%EC%97%94%EB%93%9C%20API%20%EC%97%B0%EB%8F%99%20(1)/image%206.png)

다음과 같은 화면을 얻게 되었고 JS 동작을 하나씩 살펴 보았습니다.

또한 JS 코드를 받긴 했는데 작동이 올바르게 되지 않는 부분이 있어서 해당 부분들은 수작업으로 고쳐나갔습니다.

# 0. 공통

가장 먼저 AI에게 필요한 css, html 코드를 받고 JS에서 querySelector를 통해 받아왔습니다.

- JS 코드
    
    ```jsx
    // 여기부터는 html에 있는 요소들을 JS에서 가져오기 위해서 변수에 매핑하는 것
    // querySelector로 HTML 문서에서 가져옴
    const globalMessage = document.querySelector("#global-message");
    
    const loginSection = document.querySelector("#login-section");
    const signupSection = document.querySelector("#signup-section");
    
    const postListSection = document.querySelector("#post-list-section");
    const postCreateSection = document.querySelector("#post-create-section");
    const postDetailSection = document.querySelector("#post-detail-section");
    const postEditSection = document.querySelector("#post-edit-section");
    
    const showListButton = document.querySelector("#show-list-button");
    const showCreateButton = document.querySelector("#show-create-button");
    const showLoginButton = document.querySelector("#show-login-button");
    const showSignupButton = document.querySelector("#show-signup-button");
    const logoutButton = document.querySelector("#logout-button");
    
    const loginStatusText = document.querySelector("#login-status-text");
    
    const signupEmailInput = document.querySelector("#signup-email-input");
    const signupPasswordInput = document.querySelector("#signup-password-input");
    const signupNicknameInput = document.querySelector("#signup-nickname-input");
    const signupButton = document.querySelector("#signup-button");
    const cancelSignupButton = document.querySelector("#cancel-signup-button");
    
    const loginEmailInput = document.querySelector("#login-email-input");
    const loginPasswordInput = document.querySelector("#login-password-input");
    const loginButton = document.querySelector("#login-button");
    const cancelLoginButton = document.querySelector("#cancel-login-button");
    
    const refreshPostsButton = document.querySelector("#refresh-posts-button");
    const postList = document.querySelector("#post-list");
    
    const prevPageButton = document.querySelector("#prev-page-button");
    const nextPageButton = document.querySelector("#next-page-button");
    const pageInfo = document.querySelector("#page-info");
    
    const createTitleInput = document.querySelector("#create-title-input");
    const createContentInput = document.querySelector("#create-content-input");
    const createPostButton = document.querySelector("#create-post-button");
    const cancelCreateButton = document.querySelector("#cancel-create-button");
    const saveDraftButton = document.querySelector("#save-draft-button");
    const loadDraftButton = document.querySelector("#load-draft-button");
    
    const detailTitle = document.querySelector("#detail-title");
    const detailAuthor = document.querySelector("#detail-author");
    const detailCreatedAt = document.querySelector("#detail-created-at");
    const detailEdited = document.querySelector("#detail-edited");
    const detailContent = document.querySelector("#detail-content");
    const detailViewCount = document.querySelector("#detail-view-count");
    const detailLikeCount = document.querySelector("#detail-like-count");
    const detailCommentCount = document.querySelector("#detail-comment-count");
    
    const backToListButton = document.querySelector("#back-to-list-button");
    const showEditButton = document.querySelector("#show-edit-button");
    const deletePostButton = document.querySelector("#delete-post-button");
    const likePostButton = document.querySelector("#like-post-button");
    
    const editTitleInput = document.querySelector("#edit-title-input");
    const editContentInput = document.querySelector("#edit-content-input");
    const updatePostButton = document.querySelector("#update-post-button");
    const cancelEditButton = document.querySelector("#cancel-edit-button");
    
    const reportReasonInput = document.querySelector("#report-reason-input");
    const reportPostButton = document.querySelector("#report-post-button");
    
    const commentList = document.querySelector("#comment-list");
    const commentInput = document.querySelector("#comment-input");
    const createCommentButton = document.querySelector("#create-comment-button");
    ```
    

그리고 클릭했을 때 화면 설정을 할 수 있도록 `showSection` 함수를 설정하였습니다.

각각 버튼에 `EventListener` 를 모두 설정해 두었습니다

그 결과 목록, 글쓰기, 로그인, 회원가입까지 이동이 완료되었습니다.

## JSON 요청 옵션 만드는 함수

서버로 fetch를 보낼 때 JS 객체를 JSON으로 바꾸는 방법에 대해 AI에게 질문하였고

```jsx
function getJsonOptions(method, body) {
  return {
    method: method,
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(body)
  };
}
```

다음 함수를 통해 JSON으로 변경 가능한 점을 알게되었습니다.

## 에러 응답

```jsx
async function getErrorMessage(response, fallbackMessage) {
  try {
    const errorResult = await response.json();
    return errorResult.message || fallbackMessage;
  } catch (error) {
    return fallbackMessage;
  }
}

```

응답에 에러가 있다면 해당 에러 출력

# 1. 사용자

## 회원가입

- 회원가입 JS
    
    ```jsx
    // 회원가입 함수
    async function signup() {
        //이메일, 비번, 닉네임 모두 입력값을 변수로 저장 
      const email = signupEmailInput.value;
      const password = signupPasswordInput.value;
      const nickname = signupNicknameInput.value;
        // 만약 하나라도 비어있다면 메시지 출력 및 에러
      if (email.trim() === "" || password.trim() === "" || nickname.trim() === "") {
        showMessage("회원가입 정보를 모두 입력하세요.", "error");
        return;
      }
      // 서버로 보내기 전에 body에 저장
      const body = {
        email: email,
        password: password,
        nickname: nickname
      };
    
      try {
        // 응답 변수 만들고 fetch 통해 요청 보냄
        const response = await fetch(
          API_BASE_URL + "/users/register",
          getJsonOptions("POST", body)
        );
    
        // 만약 응답이 ok가 아니라면 실패 에러 던짐
        if (!response.ok) {
          throw new Error("회원가입에 실패했습니다.");
        }
    
        //다시 입력칸 초기화 하고 성공 메시지 출력
        signupEmailInput.value = "";
        signupPasswordInput.value = "";
        signupNicknameInput.value = "";
    
        showMessage("회원가입이 완료되었습니다. 로그인해주세요.", "success");
        showSection("login");
    
        // 회원가입 실패시 에러 메시지 출력
      } catch (error) {
        showMessage(error.message, "error");
      }
    }
    ```
    

![image.png](Vanila%20JS%EB%A1%9C%20%EA%B8%B0%ED%9A%8D%EC%84%9C%20%EC%9A%94%EA%B5%AC%EC%82%AC%ED%95%AD%EC%97%90%20%EB%A7%9E%EC%B6%B0%20%ED%94%84%EB%A1%A0%ED%8A%B8%EC%97%94%EB%93%9C%20%EA%B5%AC%EC%84%B1%20%EB%B0%8F%20%EB%B0%B1%EC%97%94%EB%93%9C%20API%20%EC%97%B0%EB%8F%99%20(1)/image%207.png)

의도한대로 성공 후 바로 로그인 화면으로 가도록 설정하였습니다.

[회원가입 리팩토링](Vanila%20JS%EB%A1%9C%20%EA%B8%B0%ED%9A%8D%EC%84%9C%20%EC%9A%94%EA%B5%AC%EC%82%AC%ED%95%AD%EC%97%90%20%EB%A7%9E%EC%B6%B0%20%ED%94%84%EB%A1%A0%ED%8A%B8%EC%97%94%EB%93%9C%20%EA%B5%AC%EC%84%B1%20%EB%B0%8F%20%EB%B0%B1%EC%97%94%EB%93%9C%20API%20%EC%97%B0%EB%8F%99%20(1)/%ED%9A%8C%EC%9B%90%EA%B0%80%EC%9E%85%20%EB%A6%AC%ED%8C%A9%ED%86%A0%EB%A7%81%205587bf5f5a8583c792ee0107fc4a015c.md)

## 로그인

- 로그인 JS
    
    ```jsx
    // 로그인 함수
    async function login() {
        // 인풋 값 받아오고
      const email = loginEmailInput.value;
      const password = loginPasswordInput.value;
    
      // 회원가입과 마찬가지로 비어있는지 확인
      if (email.trim() === "" || password.trim() === "") {
        showMessage("이메일과 비밀번호를 입력하세요.", "error");
        return;
      }
      //서버로 보낼 body 설정
      const body = {
        email: email,
        password: password
      };
      // 로그인해보고 오류나면 오류 던지기
      try {
        const response = await fetch(
          API_BASE_URL + "/users/login",
          getJsonOptions("POST", body)
        );
    
        if (!response.ok) {
          throw new Error("로그인에 실패했습니다.");
        }
    
        const result = await response.json();
    
        // 현재 사용자 아이디 설정후 로컬스토리지에 저장 getItem으로 꺼내기 가능
        currentUserId = Number(result.data.userId);
        localStorage.setItem("userId", currentUserId);
    
        // 다시 로그인 창 벨류 빈칸 설정
        loginEmailInput.value = "";
        loginPasswordInput.value = "";
    
        // 로그인상태창 변경
        renderLoginStatus();
        showMessage("로그인했습니다.", "success");
        showSection("list");
      } catch (error) {
        showMessage(error.message, "error");
      }
    }
    
    ```
    

![image.png](Vanila%20JS%EB%A1%9C%20%EA%B8%B0%ED%9A%8D%EC%84%9C%20%EC%9A%94%EA%B5%AC%EC%82%AC%ED%95%AD%EC%97%90%20%EB%A7%9E%EC%B6%B0%20%ED%94%84%EB%A1%A0%ED%8A%B8%EC%97%94%EB%93%9C%20%EA%B5%AC%EC%84%B1%20%EB%B0%8F%20%EB%B0%B1%EC%97%94%EB%93%9C%20API%20%EC%97%B0%EB%8F%99%20(1)/image%208.png)

로그인 성공 후 게시글 목록 페이지로 잘 이동하였습니다.

## 토글 추가

![image.png](Vanila%20JS%EB%A1%9C%20%EA%B8%B0%ED%9A%8D%EC%84%9C%20%EC%9A%94%EA%B5%AC%EC%82%AC%ED%95%AD%EC%97%90%20%EB%A7%9E%EC%B6%B0%20%ED%94%84%EB%A1%A0%ED%8A%B8%EC%97%94%EB%93%9C%20%EA%B5%AC%EC%84%B1%20%EB%B0%8F%20%EB%B0%B1%EC%97%94%EB%93%9C%20API%20%EC%97%B0%EB%8F%99%20(1)/image%209.png)

로그인 중일 때만 보이는 토글을 설치하여서

프로필 이미지가 없다면 기본 프로필로 있다면 해당 프로필을 표기하도록 수정하였습니다.

또한 회원정보 보기, 수정, 탈퇴를 넣어서 바로 갈 수 있도록 수정하였습니다.

# 2. 게시글

## 게시글 목록 불러오기

게시글 표시가 너무 감이 안잡혀서 코드를 요청하였습니다. 

- appendChild
- createElement
- textContent

를 학습하고 코드를 이해하였습니다.

각각의 요소를 만들고 appendChild를 통해 자식으로 넣고 최종적으로 조립하는 과정이였습니다.

아직 글쓰기 버튼은 이벤트를 안 넣어서 더미 데이터를 넣고 확인 결과

![image.png](Vanila%20JS%EB%A1%9C%20%EA%B8%B0%ED%9A%8D%EC%84%9C%20%EC%9A%94%EA%B5%AC%EC%82%AC%ED%95%AD%EC%97%90%20%EB%A7%9E%EC%B6%B0%20%ED%94%84%EB%A1%A0%ED%8A%B8%EC%97%94%EB%93%9C%20%EA%B5%AC%EC%84%B1%20%EB%B0%8F%20%EB%B0%B1%EC%97%94%EB%93%9C%20API%20%EC%97%B0%EB%8F%99%20(1)/image%2010.png)

게시글이 올바르게 나왔습니다.

![image.png](Vanila%20JS%EB%A1%9C%20%EA%B8%B0%ED%9A%8D%EC%84%9C%20%EC%9A%94%EA%B5%AC%EC%82%AC%ED%95%AD%EC%97%90%20%EB%A7%9E%EC%B6%B0%20%ED%94%84%EB%A1%A0%ED%8A%B8%EC%97%94%EB%93%9C%20%EA%B5%AC%EC%84%B1%20%EB%B0%8F%20%EB%B0%B1%EC%97%94%EB%93%9C%20API%20%EC%97%B0%EB%8F%99%20(1)/image%2011.png)

더미데이터를 더 추가하여 이전, 다음 새로고침 버튼도 활성화 시켰습니다.

## 게시글 작성

![image.png](Vanila%20JS%EB%A1%9C%20%EA%B8%B0%ED%9A%8D%EC%84%9C%20%EC%9A%94%EA%B5%AC%EC%82%AC%ED%95%AD%EC%97%90%20%EB%A7%9E%EC%B6%B0%20%ED%94%84%EB%A1%A0%ED%8A%B8%EC%97%94%EB%93%9C%20%EA%B5%AC%EC%84%B1%20%EB%B0%8F%20%EB%B0%B1%EC%97%94%EB%93%9C%20API%20%EC%97%B0%EB%8F%99%20(1)/image%2012.png)

## 게시글 상세조회

![image.png](Vanila%20JS%EB%A1%9C%20%EA%B8%B0%ED%9A%8D%EC%84%9C%20%EC%9A%94%EA%B5%AC%EC%82%AC%ED%95%AD%EC%97%90%20%EB%A7%9E%EC%B6%B0%20%ED%94%84%EB%A1%A0%ED%8A%B8%EC%97%94%EB%93%9C%20%EA%B5%AC%EC%84%B1%20%EB%B0%8F%20%EB%B0%B1%EC%97%94%EB%93%9C%20API%20%EC%97%B0%EB%8F%99%20(1)/image%2013.png)

같은 사용자인데도 삭제 수정 버튼이 안보여서 콘솔 로그로 찍어보았습니다.

![image.png](Vanila%20JS%EB%A1%9C%20%EA%B8%B0%ED%9A%8D%EC%84%9C%20%EC%9A%94%EA%B5%AC%EC%82%AC%ED%95%AD%EC%97%90%20%EB%A7%9E%EC%B6%B0%20%ED%94%84%EB%A1%A0%ED%8A%B8%EC%97%94%EB%93%9C%20%EA%B5%AC%EC%84%B1%20%EB%B0%8F%20%EB%B0%B1%EC%97%94%EB%93%9C%20API%20%EC%97%B0%EB%8F%99%20(1)/image%2014.png)

그 결과 백엔드 서버에서 사용자 아이디를 넘기지 않아서 DTO에 추가하였습니다.

그 결과 같은 사용자는 수정, 삭제 버튼이 활성화됨을 확인하였고

![image.png](Vanila%20JS%EB%A1%9C%20%EA%B8%B0%ED%9A%8D%EC%84%9C%20%EC%9A%94%EA%B5%AC%EC%82%AC%ED%95%AD%EC%97%90%20%EB%A7%9E%EC%B6%B0%20%ED%94%84%EB%A1%A0%ED%8A%B8%EC%97%94%EB%93%9C%20%EA%B5%AC%EC%84%B1%20%EB%B0%8F%20%EB%B0%B1%EC%97%94%EB%93%9C%20API%20%EC%97%B0%EB%8F%99%20(1)/image%2015.png)

다른 사용자는 막음을 확인하였습니다.

→ 백엔드에서 넘겨주는 데이터의 정확성이 중요하다는 것을 깨달았습니다,,

![image.png](Vanila%20JS%EB%A1%9C%20%EA%B8%B0%ED%9A%8D%EC%84%9C%20%EC%9A%94%EA%B5%AC%EC%82%AC%ED%95%AD%EC%97%90%20%EB%A7%9E%EC%B6%B0%20%ED%94%84%EB%A1%A0%ED%8A%B8%EC%97%94%EB%93%9C%20%EA%B5%AC%EC%84%B1%20%EB%B0%8F%20%EB%B0%B1%EC%97%94%EB%93%9C%20API%20%EC%97%B0%EB%8F%99%20(1)/image%2016.png)

## 게시글 수정

![image.png](Vanila%20JS%EB%A1%9C%20%EA%B8%B0%ED%9A%8D%EC%84%9C%20%EC%9A%94%EA%B5%AC%EC%82%AC%ED%95%AD%EC%97%90%20%EB%A7%9E%EC%B6%B0%20%ED%94%84%EB%A1%A0%ED%8A%B8%EC%97%94%EB%93%9C%20%EA%B5%AC%EC%84%B1%20%EB%B0%8F%20%EB%B0%B1%EC%97%94%EB%93%9C%20API%20%EC%97%B0%EB%8F%99%20(1)/image%2017.png)

수정도 원할하게 되었습니다.

# 3. 댓글

## 댓글 작성

![image.png](Vanila%20JS%EB%A1%9C%20%EA%B8%B0%ED%9A%8D%EC%84%9C%20%EC%9A%94%EA%B5%AC%EC%82%AC%ED%95%AD%EC%97%90%20%EB%A7%9E%EC%B6%B0%20%ED%94%84%EB%A1%A0%ED%8A%B8%EC%97%94%EB%93%9C%20%EA%B5%AC%EC%84%B1%20%EB%B0%8F%20%EB%B0%B1%EC%97%94%EB%93%9C%20API%20%EC%97%B0%EB%8F%99%20(1)/image%2018.png)

처음 댓글을 달았더니 no content라는 오류가 떴습니다. 

분명히 내용을 넣었는데,, 코드를 다시 확인해보니 아무 생각없이 js 코드에 content라고 내용을 붙였던 것이 백엔드 코드에서는 comment로 되어있어서 변수명 오류가 되어있었습니다.

![image.png](Vanila%20JS%EB%A1%9C%20%EA%B8%B0%ED%9A%8D%EC%84%9C%20%EC%9A%94%EA%B5%AC%EC%82%AC%ED%95%AD%EC%97%90%20%EB%A7%9E%EC%B6%B0%20%ED%94%84%EB%A1%A0%ED%8A%B8%EC%97%94%EB%93%9C%20%EA%B5%AC%EC%84%B1%20%EB%B0%8F%20%EB%B0%B1%EC%97%94%EB%93%9C%20API%20%EC%97%B0%EB%8F%99%20(1)/image%2019.png)

테스트 댓글도 성공적으로 작성하였습니다.

하지만 문제가 댓글 삭제 버튼이 안나왔습니다. 백엔드에서 응답을 내려줄 때 댓글 작성한 작성자 아이디를 넘겨주지 않아서 비교를 해도 비교가 안되는 상황이였습니다.

즉

```jsx
if (comment.deleted !== true && commentAuthorId === currentUserId) {
    const buttonRow = document.createElement("div");
    buttonRow.classList.add("comment-button-row");

    const deleteButton = document.createElement("button");
    deleteButton.classList.add("danger");
    deleteButton.textContent = "댓글 삭제";

    deleteButton.addEventListener("click", function (event) {
      event.stopPropagation();
      deleteComment(comment.commentId);
    });

    buttonRow.appendChild(deleteButton);
    commentItem.appendChild(buttonRow);
  }
```

해당 코드에서 commentAuthorId 자체가 인식이 안되었던 것입니다.

![image.png](Vanila%20JS%EB%A1%9C%20%EA%B8%B0%ED%9A%8D%EC%84%9C%20%EC%9A%94%EA%B5%AC%EC%82%AC%ED%95%AD%EC%97%90%20%EB%A7%9E%EC%B6%B0%20%ED%94%84%EB%A1%A0%ED%8A%B8%EC%97%94%EB%93%9C%20%EA%B5%AC%EC%84%B1%20%EB%B0%8F%20%EB%B0%B1%EC%97%94%EB%93%9C%20API%20%EC%97%B0%EB%8F%99%20(1)/image%2020.png)

![image.png](Vanila%20JS%EB%A1%9C%20%EA%B8%B0%ED%9A%8D%EC%84%9C%20%EC%9A%94%EA%B5%AC%EC%82%AC%ED%95%AD%EC%97%90%20%EB%A7%9E%EC%B6%B0%20%ED%94%84%EB%A1%A0%ED%8A%B8%EC%97%94%EB%93%9C%20%EA%B5%AC%EC%84%B1%20%EB%B0%8F%20%EB%B0%B1%EC%97%94%EB%93%9C%20API%20%EC%97%B0%EB%8F%99%20(1)/image%2021.png)

댓글 작성자가 아니면 삭제 버튼이 비활성화 되도록 설정하였습니다.

댓글 수정 버튼도 마찬가지로 같은 사용자일 때 활성화 시켰습니다.

![image.png](Vanila%20JS%EB%A1%9C%20%EA%B8%B0%ED%9A%8D%EC%84%9C%20%EC%9A%94%EA%B5%AC%EC%82%AC%ED%95%AD%EC%97%90%20%EB%A7%9E%EC%B6%B0%20%ED%94%84%EB%A1%A0%ED%8A%B8%EC%97%94%EB%93%9C%20%EA%B5%AC%EC%84%B1%20%EB%B0%8F%20%EB%B0%B1%EC%97%94%EB%93%9C%20API%20%EC%97%B0%EB%8F%99%20(1)/image%2022.png)

근데 수정하고 나서 수정했습니다 메시지가 안뜨고 게시글 목록 불러오기 완료가 계속 떠서

```jsx
if (showSuccessMessage === true){
        showMessage("게시글 상세를 불러왔습니다.", "success");
    }
```

해당 코드를 통해 게시글 상세 불러오는 것은 SuccessMessage가 true일때만 불러오도록 변경하였습니다.

# 4. 좋아요

![image.png](Vanila%20JS%EB%A1%9C%20%EA%B8%B0%ED%9A%8D%EC%84%9C%20%EC%9A%94%EA%B5%AC%EC%82%AC%ED%95%AD%EC%97%90%20%EB%A7%9E%EC%B6%B0%20%ED%94%84%EB%A1%A0%ED%8A%B8%EC%97%94%EB%93%9C%20%EA%B5%AC%EC%84%B1%20%EB%B0%8F%20%EB%B0%B1%EC%97%94%EB%93%9C%20API%20%EC%97%B0%EB%8F%99%20(1)/image%2023.png)

좋아요도 한번 누르면 좋아요 취소 버튼이 원래 안떠서 

프론트단에 liked 변수를 추가하여 같이 응답 DTO에 보내주었습니다.

```jsx
let currentPostLiked = false;
```

그리고 

상세 페이지 랜더링 함수에서

```jsx
  currentPostLiked = post.liked === true;
  if (currentPostLiked) {
    likePostButton.textContent = "좋아요 취소";
  } else {
    likePostButton.textContent = "좋아요";
  }
```

다음 코드를 넣어서 백엔드에서 받아온 `liked` 변수와 비교하여 새 값을 집어 넣었습니다.

# 5. 신고

![image.png](Vanila%20JS%EB%A1%9C%20%EA%B8%B0%ED%9A%8D%EC%84%9C%20%EC%9A%94%EA%B5%AC%EC%82%AC%ED%95%AD%EC%97%90%20%EB%A7%9E%EC%B6%B0%20%ED%94%84%EB%A1%A0%ED%8A%B8%EC%97%94%EB%93%9C%20%EA%B5%AC%EC%84%B1%20%EB%B0%8F%20%EB%B0%B1%EC%97%94%EB%93%9C%20API%20%EC%97%B0%EB%8F%99%20(1)/image%2024.png)

신고를 하면 reportCount를 하나 늘려주는데 성공하였습니다.

![image.png](Vanila%20JS%EB%A1%9C%20%EA%B8%B0%ED%9A%8D%EC%84%9C%20%EC%9A%94%EA%B5%AC%EC%82%AC%ED%95%AD%EC%97%90%20%EB%A7%9E%EC%B6%B0%20%ED%94%84%EB%A1%A0%ED%8A%B8%EC%97%94%EB%93%9C%20%EA%B5%AC%EC%84%B1%20%EB%B0%8F%20%EB%B0%B1%EC%97%94%EB%93%9C%20API%20%EC%97%B0%EB%8F%99%20(1)/image%2025.png)

또한 게시글 목록과 상세페이지를 5번 신고되면 블라인드로 바꾸었습니다.

→ 아예 상세 페이지를 들어가지 못하게 하는게 나은건지는 모르겠습니다,,

```jsx
if (response.blinded === true){
        loadPosts(0);
    } else {
        loadPostDetail(currentPostId, false);
    }
    
```

신고 5번이 될때 상세조회말고 목록으로가고 상세 페이지 접근 자체를막아보려고 했는데 안되었습니다

→ 원인은 `response` 는 서버가 보내준 JSON 데이터가 아니라 fetch Response 객체여서 data에 한번 들어가서 blinded를 꺼내주었어야 했습니다.

![image.png](Vanila%20JS%EB%A1%9C%20%EA%B8%B0%ED%9A%8D%EC%84%9C%20%EC%9A%94%EA%B5%AC%EC%82%AC%ED%95%AD%EC%97%90%20%EB%A7%9E%EC%B6%B0%20%ED%94%84%EB%A1%A0%ED%8A%B8%EC%97%94%EB%93%9C%20%EA%B5%AC%EC%84%B1%20%EB%B0%8F%20%EB%B0%B1%EC%97%94%EB%93%9C%20API%20%EC%97%B0%EB%8F%99%20(1)/image%2026.png)

근데 그래도 blinded를 못 읽어서 확인을 해보았습니다.

이는 response의 응답 body를 JSON에서 JS객체로 변환해서 꺼내는 것입니다.

따라서JS 객체로 변환하는 작업을 

```jsx
const result = await response.json();
```

다음 코드를 통해 해결하였습니다.

![image.png](Vanila%20JS%EB%A1%9C%20%EA%B8%B0%ED%9A%8D%EC%84%9C%20%EC%9A%94%EA%B5%AC%EC%82%AC%ED%95%AD%EC%97%90%20%EB%A7%9E%EC%B6%B0%20%ED%94%84%EB%A1%A0%ED%8A%B8%EC%97%94%EB%93%9C%20%EA%B5%AC%EC%84%B1%20%EB%B0%8F%20%EB%B0%B1%EC%97%94%EB%93%9C%20API%20%EC%97%B0%EB%8F%99%20(1)/image%2027.png)

그런결과 게시글 목록으로 돌아가는 것에 성공하였습니다.

또한 블라인드 처리된 게시글은 상세조회도 못하도록 바꿔보았습니다.

```jsx
if (post.blinded !== true) {
    postCard.addEventListener("click", function () {
        loadPostDetail(post.postId);
    });
    } else {
    postCard.style.cursor = "not-allowed";
    }

```

해당 코드를 통해서 클릭 조차 못하도록 변경하였습니다.

# 6. 임시저장

![image.png](Vanila%20JS%EB%A1%9C%20%EA%B8%B0%ED%9A%8D%EC%84%9C%20%EC%9A%94%EA%B5%AC%EC%82%AC%ED%95%AD%EC%97%90%20%EB%A7%9E%EC%B6%B0%20%ED%94%84%EB%A1%A0%ED%8A%B8%EC%97%94%EB%93%9C%20%EA%B5%AC%EC%84%B1%20%EB%B0%8F%20%EB%B0%B1%EC%97%94%EB%93%9C%20API%20%EC%97%B0%EB%8F%99%20(1)/image%2028.png)

임시저장 또한 확인하였습니다.

---

# 7. 코드 분리

html, css, js를 한 코드로 모두 사용하다보니 너무 코드가 길어져서 js 코드는 거의 1000줄이 넘어버렸습니다.

가독성을 위해 AI에게 나누는 법(모듈 사용?)을 물어보았습니다.

```jsx
vanilla-js/
├── index.html
├── style.css
└── js/
    ├── state.js
    ├── dom.js
    ├── common.js
    ├── auth.js
    ├── posts.js
    ├── comments.js
    ├── drafts.js
    └── events.js
```

다음 구조로 나누고 

HTML script 부분을

```jsx
<script src="./js/state.js"></script>
<script src="./js/dom.js"></script>
<script src="./js/common.js"></script>
<script src="./js/auth.js"></script>
<script src="./js/posts.js"></script>
<script src="./js/comments.js"></script>
<script src="./js/drafts.js"></script>
<script src="./js/events.js"></script>
```

다음으로 수정하라고 하였습니다.

![image.png](Vanila%20JS%EB%A1%9C%20%EA%B8%B0%ED%9A%8D%EC%84%9C%20%EC%9A%94%EA%B5%AC%EC%82%AC%ED%95%AD%EC%97%90%20%EB%A7%9E%EC%B6%B0%20%ED%94%84%EB%A1%A0%ED%8A%B8%EC%97%94%EB%93%9C%20%EA%B5%AC%EC%84%B1%20%EB%B0%8F%20%EB%B0%B1%EC%97%94%EB%93%9C%20API%20%EC%97%B0%EB%8F%99%20(1)/image%2029.png)

그 결과 훨씬 가독성이 올라갔습니다.

HTML, CSS 수정 관련 물어보니 나누지 않는 것이 좋다고 하여 변경하지 않았습니다.