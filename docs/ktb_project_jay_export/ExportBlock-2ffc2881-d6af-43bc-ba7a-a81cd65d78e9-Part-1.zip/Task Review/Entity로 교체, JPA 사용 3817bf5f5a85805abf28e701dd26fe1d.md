# Entity로 교체, JPA 사용

주차: 6
진행상황: 완료

### 저번주차 피드백 결과

[피드백 반영 (1)](Entity%EB%A1%9C%20%EA%B5%90%EC%B2%B4,%20JPA%20%EC%82%AC%EC%9A%A9/%ED%94%BC%EB%93%9C%EB%B0%B1%20%EB%B0%98%EC%98%81%20(1)%203b67bf5f5a8580238d71eb6f541d8a29.md)

### 상황 한줄 정리

- [x]  H2 DB 의존성 추가하여 Spring Boot에 연결(강의 페이지 내 H2 DB 연결 - 미니퀘스트 진행)
- [x]  (선택) 교재의 과제 / 미니 퀘스트를 현재 프로젝트에 맞게 진행
- [x]  ERD 설계를 기반으로 Entity 구성
- [x]  기존 DB처럼 작업한 내용(ex>inmemory db)을 H2 DB, JPA로 변경하여 적용
- [x]  동일하게 수행하는지 확인

### 프로젝트 결과물

https://github.com/100-hours-a-week/KTB4_Jay_Week6

### AI 사용 기록

[AI 사용 기록 (1)](Entity%EB%A1%9C%20%EA%B5%90%EC%B2%B4,%20JPA%20%EC%82%AC%EC%9A%A9/AI%20%EC%82%AC%EC%9A%A9%20%EA%B8%B0%EB%A1%9D%20(1)%203b67bf5f5a858021ae4ee125b2b5f181.md)

## 회고

[회고 - 과제 진행 (1)](Entity%EB%A1%9C%20%EA%B5%90%EC%B2%B4,%20JPA%20%EC%82%AC%EC%9A%A9/%ED%9A%8C%EA%B3%A0%20-%20%EA%B3%BC%EC%A0%9C%20%EC%A7%84%ED%96%89%20(1)%203b67bf5f5a85805c8c5dd697d28feb28.md)

[회고 - 느낀점 및 질문 (1)](Entity%EB%A1%9C%20%EA%B5%90%EC%B2%B4,%20JPA%20%EC%82%AC%EC%9A%A9/%ED%9A%8C%EA%B3%A0%20-%20%EB%8A%90%EB%82%80%EC%A0%90%20%EB%B0%8F%20%EC%A7%88%EB%AC%B8%20(1)%203b67bf5f5a858026aea7c4b24c8efc5b.md)

## 강사 답변

1. 이번 회고에서 좋았던 부분은 JPA를 어노테이션 외워 붙이는 데서 멈추지 않고 persist와 flush와 clear를 직접 돌려가며 언제 INSERT가 나가는지, 1차 캐시가 언제 SELECT를 막는지, 더티 체킹이 정말 UPDATE를 내보내는지를 **눈으로 확인한 점**입니다. IDENTITY와 SEQUENCE를 바꿔가며 쓰기 지연 차이를 본 것이나, flush와 clear를 빼면 1차 캐시 때문에 N 더하기 1이 안 보이다가 비워주면 그제야 드러나는 걸 잡아낸 것은 쿼리가 실제로 어떻게 나가는지 따지기 시작했다는 신호라고 생각합니다. **p6spy까지 붙여 SQL을 직접 본 습관**은 그대로 가져가면 좋겠습니다. 실무에서 성능 문제는 결국 이 쿼리 로그를 읽을 줄 아는 사람이 잡습니다. 그리고 거의 모든 기능에서 탈퇴 사용자 확인과 id 존재 확인이 똑같이 반복된다는 걸 스스로 알아채고 공통 처리로 묶을 수 있는지 고민한 점도 좋았습니다. 아직 구현은 못 했다고 하셨는데 중복이 눈에 거슬리기 시작했다는 것 자체가 다음 단계로 갈 준비가 됐다는 뜻이라 너무 조급해하지 않아도 됩니다. codex에는 수정은 막고 조회만 시켜서, commentCount가 바뀌긴 하는데 정작 count 쿼리로 엉뚱한 값을 주던 문제를 찾아내고 AI가 권한 방향 대신 본인 판단으로 다른 방향을 고른 뒤 그게 맞는지 다시 질문으로 남기셨네요. AI 답을 그대로 받지 않고 한 번 의심해본 태도가 좋습니다. 남겨주신 질문들 이어서 답하겠습니다.
    1. 실무에서 함수명이 바뀔 때는 IDE의 rename 리팩토링으로 참조까지 한 번에 바꾸고, 놓친 호출부는 컴파일과 테스트가 잡아줍니다. 외부에 공개된 API나 컬럼이면 한 번에 바꾸지 않고 기존 이름을 deprecated로 한동안 같이 두었다가 나중에 제거하는 식으로 갑니다.
    2. 기본값 초기화는 viewCount나 blinded처럼 단순 상수면 필드 초기화로 두어 생성자를 가볍게 하고, createdAt처럼 저장 시점에 정해지는 값은 @PrePersist로 빼는 편이 깔끔하지 않을까요. 정답이 하나는 아니고 팀 안에서 한 방식으로 통일하는 게 더 중요합니다.
    3. 최신순 정렬은 서버에서 order by로 정렬해 내려주는 게 맞고, 이미 fetch join 쿼리에서 createdAt 내림차순으로 하고 계십니다. 페이지네이션이 들어가면 프론트는 한 페이지만 받기 때문에 전체 기준 정렬은 서버 몫입니다.
    4. 폴더 구조는 지금처럼 도메인별로 묶는 방식이 실무에서도 더 선호되는 편입니다. 기능 하나가 한 패키지에 모여 응집도가 높고, 계층별로 나누면 기능 하나 고칠 때 여러 폴더를 오가야 합니다. 지금 구조를 유지하면 좋겠습니다. 
    5. 댓글 수는 둘 다 쓰는 방법입니다. 트레이드 오프라고 생각합니다. count 쿼리는 항상 정확하고 단순해서 인덱스가 있으면 병목이 되기 전까지 충분하고, 변수로 들고 있는 방식은 읽기는 빠르지만 댓글 생성과 삭제와 soft delete까지 모든 경로에서 정확히 증감시켜야 하며 한 곳만 빠져도 값이 어긋납니다. codex가 정합성이 먼저라고 한 게 그 뜻이고, jay가 겪은 엉뚱한 값도 같은 함정입니다.
2. 가장 먼저 봐야 할 부분입니다. PostService에는 클래스에도 메서드에도 @Transactional이 하나도 없습니다. 문제는 deletePost가 post.delete로 deletedAt만 세팅하고 끝나고 updatePost도 post.update로 제목과 내용을 바꾸기만 한다는 점입니다. 변경 감지는 트랜잭션 안에서만 동작하는데 트랜잭션이 없으니 이 변경이 flush되지 않고, 결국 soft delete와 게시글 수정이 실제 DB에는 반영되지 않습니다. 응답은 메모리에 있는 객체로 만들어 내려주니 호출한 쪽에서는 성공처럼 보이지만 다시 조회하면 그대로입니다. 그리고 작성하신 테스트는 @Transactional이나 @DataJpaTest로 감싸져 있어서 테스트 안에서는 트랜잭션이 열려 있으니 이 버그가 안 잡힙니다.
3. Post와 Comment의 content가 길이 지정 없는 String이라 H2에서 VARCHAR 255로 매핑되는데, 5주차 ERD는 TEXT라서 255자가 넘는 본문은 저장이 실패합니다. 짧은 값으로만 테스트해 안 드러났을 뿐 실제 글 길이로 쓰면 막히고 전역 핸들러가 안 잡아 500으로 나가니, content에 columnDefinition을 TEXT로 주거나 @Lob으로 매핑해 ERD와 맞춰주면 좋겠습니다. PostDraft의 content도 같습니다.
4. 댓글 수가 목록과 상세에서 다르게 나옵니다. 목록 getPost는 post.getCommentCount 카운터를 쓰는데 상세 getPostDetail은 countByPostId를 쓰고, 이 쿼리에는 deletedAt과 parentComment 조건이 없어 대댓글과 삭제된 댓글까지 세어져 상세 쪽이 더 커집니다. 댓글 응답은 카운터로 통일하셨는데 상세 조회만 빠졌으니, 상세도 post.getCommentCount로 맞추거나 count 쿼리에 deletedAt is null과 parentComment is null 조건을 넣어주면 좋겠습니다.
5.  게시글과 작성자 사이 N + 1은 fetch join으로 잘 푸셨는데 댓글 쪽은 남아 있습니다. 상세 조회의 getComments와 getReplies가 댓글마다 userRepository의 findById로 작성자를 다시 불러오는데, findParentCommentsByPost_Id와 findRepliesByParentComment_Id가 author를 join fetch하지 않아 댓글 작성자 수만큼 쿼리가 더 나갑니다. 댓글 조회에서 author를 join fetch로 같이 가져오면 좋겠습니다.
6. getPost와 getPostDetail은 이미 fetch join으로 author를 가져왔는데도 userRepository의 findById로 작성자를 한 번 더 조회합니다. 지금은 1차 캐시 덕에 추가 쿼리는 안 나가지만 fetch join이 무의미해지고 join을 빼는 순간 N + 1로 돌아가니, 이미 가져온 post.getAuthor를 그대로 쓰면 됩니다.
7. 게시글 목록을 findAllWithAuthorFetchJoin이 List로 통째로 반환해서 글이 쌓이면 한 번에 전부 로딩됩니다. 작성자는 fetch join이라 페이징과 같이 써도 문제가 없으니 Pageable을 받아 페이지 단위로 끊어 반환하면 좋겠습니다.
8. 검증이 전부 Service 안 if문으로 들어가 register와 login과 post와 saveDraft마다 null과 isBlank 체크가 반복됩니다. 요청 DTO에 @NotBlank를 붙이고 컨트롤러에서 @Valid로 받으면 줄어드는데, 대신 MethodArgumentNotValidException 핸들러를 같이 추가해주면 됩니다.
9. 거의 모든 서비스가 userRepository의 findById 후 isDeleted를 확인하는 코드를 똑같이 반복합니다. 활성 사용자를 찾아주는 메서드 하나로 모으면 중복이 정리되고 탈퇴 정책이 바뀔 때 한 곳만 고치면 되서 좋을것 같습니다.

---

### 비고

-