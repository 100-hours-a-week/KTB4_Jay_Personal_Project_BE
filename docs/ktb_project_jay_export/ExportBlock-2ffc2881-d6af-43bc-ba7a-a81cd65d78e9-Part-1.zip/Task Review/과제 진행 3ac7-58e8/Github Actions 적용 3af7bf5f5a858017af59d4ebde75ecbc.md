# Github Actions 적용

<aside>
👉

아무말 대잔치 FE, BE를 Github Actions로 CI/CD 파이프라인 구현해 배포해보세요.

- 배포 단계에서는 MySQL, FE, BE, Nginx 가 Docker compose를 활용해 한번에 컨테이너 생성이 되어야합니다.
</aside>

이번주 과제는 Github Actions로 CI/CD 파이프라인을 구축하는 것입니다.

11주차 과제에서 이미 docker까지 설정을 하여서 이번주에는 깃허브에 push했을 때 자동으로 테스트하고 이미지 만들어서 docker hub에 저장하고 이미지를 EC2에서 받게 하는 과정을 만들려고 합니다.

# 1. Registry 만들기

일단 기존에는 EC2 내부에 이미지를 저장하여서 깃헙 액션을 사용하기 위해 Docker hub을 만들었습니다

![image.png](Github%20Actions%20%EC%A0%81%EC%9A%A9/image.png)

# 2. 로컬에서 이미지 빌드하고 docker hub 올려지는지 확인

```bash
docker build \
  --platform linux/amd64 \
  -t ktbjay/community-backend:latest \
  .
```

를 통해서 이미지 빌드한뒤 

```bash
docker push ktbjay/community-backend:latest
```

를 통해 빌드된 이미지를 docker hub로 push 했습니다.

같은 방식으로 프론트 코드도 이미지로 빌드하고 docker hub에 올린뒤 실제 docker hub에 접속해서 이미지 push한 것을 확인했습니다.

![image.png](Github%20Actions%20%EC%A0%81%EC%9A%A9/image%201.png)

![image.png](Github%20Actions%20%EC%A0%81%EC%9A%A9/9ebe50a3-0f58-418c-8e79-550b0eccb732.png)

# 3. 기존 docker compose 내용 변경

```bash
services:
  # 백엔드 Spring Boot 컨테이너 설정
  backend:
    # 백엔드 이미지를 직접 빌드한다.
    build:
      # compose.yml 기준으로 backend 폴더를 빌드 대상으로 사용한다.
      context: ./backend

      # backend 폴더 안의 Dockerfile을 사용한다.
      dockerfile: Dockerfile

    # Spring 실행 시 사용할 환경변수다.
    environment:
      # application-h2.yml 설정을 활성화한다.
      SPRING_PROFILES_ACTIVE: h2

    # 컨테이너가 비정상 종료되거나 서버가 재부팅되면 다시 시작한다.
    restart: unless-stopped

    # backend는 외부 포트를 열지 않는다.
    # frontend Nginx만 Docker 내부 네트워크로 backend:8080에 접근한다.

  # 프론트 React + Nginx 컨테이너 설정
  frontend:
    # 프론트 이미지를 직접 빌드한다.
    build:
      # compose.yml 기준으로 frontend 폴더를 빌드 대상으로 사용한다.
      context: ./frontend

      # frontend 폴더 안의 Dockerfile을 사용한다.
      dockerfile: Dockerfile

    # 호스트 EC2와 컨테이너의 포트를 연결한다.
    ports:
      # EC2 80번으로 온 요청을 프론트 컨테이너 80번으로 전달한다.
      - "80:80"

    # backend 컨테이너가 먼저 생성된 후 frontend를 생성한다.
    # 단, Spring의 완전한 준비 완료까지 보장하는 설정은 아니다.
    depends_on:
      - backend
```

기존에는 build해서 EC2 내부에서 직접 이미지를 만들지만

변경점에서는 EC2가 dokcer hub에서 이미지를 가져오는 것으로 변경했습니다.

```bash
services:
  backend:
    image: ktbjay/community-backend:latest

    environment:
      SPRING_PROFILES_ACTIVE: h2

    restart: unless-stopped

  frontend:
    image: ktbjay/community-frontend:latest

    ports:
      - "80:80"

    depends_on:
      - backend

    restart: unless-stopped
```

# 4. 이미지 pull하기

```bash
docker compose pull
```

를 통해 docker hub에서 이미지를 가져왔습니다.

# 5. 컨테이너 교체

```bash
docker compose up -d
```

원래 —build를 해줘야 하지만 이미지를 docker hub에서 가져왔기 때문에 빌드를 하지 않고 컨테이너를 교체해주었습니다.

여기까지 수동으로 docker hub에 수동으로 이미지 push와 수동으로 pull을 통해 컨테이너 실행까지 완료해서 이제 git actions 을 추가하였습니다.

# 6. Github Secrets 등록

Github Secrets애는

```bash
DOCKER_USERNAME
DOCKER_TOKEN
SSH_PRIVATE_KEY
SERVER_HOST
SERVER_USER
```

다음 정보들을 구성하였습니다.

# 7. Github Actions yml 파일 등록

```bash
name: Backend CI

on:
  push:
    branches:
      - main

  pull_request:
    branches:
      - main

jobs:
  test:
    runs-on: ubuntu-latest

    steps:
      - name: Checkout source code
        uses: actions/checkout@v4

      - name: Set up Java 21
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: "21"
          cache: gradle

      - name: Grant execute permission
        run: chmod +x gradlew

      - name: Run tests
        run: ./gradlew clean test

  build-and-push:
    needs: test

    if: github.event_name == 'push' && github.ref == 'refs/heads/main'

    runs-on: ubuntu-latest

    steps:
      - name: Checkout source code
        uses: actions/checkout@v4

      - name: Login to Docker Hub
        uses: docker/login-action@v3
        with:
          username: ${{ secrets.DOCKER_USERNAME }}
          password: ${{ secrets.DOCKER_TOKEN }}

      - name: Build backend image
        run: |
          docker build \
            --platform linux/amd64 \
            -t ${{ secrets.DOCKER_USERNAME }}/community-backend:latest \
            -t ${{ secrets.DOCKER_USERNAME }}/community-backend:${{ github.sha }} \
            .

      - name: Push backend image
        run: |
          docker push ${{ secrets.DOCKER_USERNAME }}/community-backend:latest
          docker push ${{ secrets.DOCKER_USERNAME }}/community-backend:${{ github.sha }}
```

# 8. EC2가 docker hub의 이미지 pull하는것도 자동화

```bash
  deploy:
    needs: build-and-push
    runs-on: ubuntu-latest

    steps:
      - name: Prepare SSH key
        run: |
          mkdir -p ~/.ssh
          echo "${{ secrets.SSH_PRIVATE_KEY }}" > ~/.ssh/id_rsa
          chmod 600 ~/.ssh/id_rsa
          ssh-keyscan -H "${{ secrets.SERVER_HOST }}" >> ~/.ssh/known_hosts

      - name: Deploy backend
        run: |
          ssh -i ~/.ssh/id_rsa \
            ${{ secrets.SERVER_USER }}@${{ secrets.SERVER_HOST }} << 'EOF'
              set -e
              cd ~/community-deploy
              docker compose pull backend
              docker compose up -d --no-deps backend
              docker compose ps backend
          EOF
```

![image.png](Github%20Actions%20%EC%A0%81%EC%9A%A9/image%202.png)

push하면 test 후 deploy까지 돌아가는것으로 확인했습니다.

![image.png](Github%20Actions%20%EC%A0%81%EC%9A%A9/image%203.png)

분명 SSH key 제대로 넣었는데 자꾸 안된다해서 AI에게 문의하고 bse64로 인코딩 하여서 넣었습니다.

![image.png](Github%20Actions%20%EC%A0%81%EC%9A%A9/image%204.png)

프론트도 똑같이 성공했습니다.

이제 mysql 도 .env 파일 만들어서 비번 설정하고 실제 사이트까지 배포된것 확인하고 마무리하였습니다.